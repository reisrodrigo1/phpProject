<?php
class oficinasController extends controller {

	public function __construct() {
		parent::__construct();
		$usuarios = new Usuarios();

		if(!$usuarios->isLogged()) {
			header("Location: ".BASE."login");
		}
	}
	
	public function index() {
		$dados = array(
			'oficinas' => array()
		);

		$oficinas = new Aulas();
		$dados['oficinas'] = $oficinas->getOficinas();
		
		$this->loadTemplate('oficinas', $dados);
	}

}










