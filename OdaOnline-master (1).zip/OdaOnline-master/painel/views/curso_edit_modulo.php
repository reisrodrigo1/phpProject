
<div class="content">
  <div class="row">

    <div class="col-md-7">

      <div class="card">
        <div class="card-header card-header-success">
          <h4 class="card-title">Editar Módulo</h4>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="row">
              <div class="col">
                <div class="form-group has-success">
                  <label class="special-label text-success">Nome</label>
                  <input type="text" class="form-control" name="modulo" value="<?php echo $modulo['nome']; ?>">
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-success pull-right">Salvar</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>