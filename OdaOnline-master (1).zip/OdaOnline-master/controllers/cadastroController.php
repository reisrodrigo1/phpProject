<?php
class cadastroController extends controller {

	public function __construct() {
		parent::__construct();
	}
	
	public function index() {
		$array = array();

		
    	if($_SERVER['REQUEST_METHOD'] == 'POST') {
    		$nome = $_POST['nome'];
    		$email = $_POST['email'];
    		$senha = $_POST['senha'];
    		$confirmsenha = $_POST['confirmsenha'];
    		$nomeResponsavel = $_POST['nomeResponsavel'];
    		$cupom = $_POST['cupom'];

			if((isset($nome) && !empty($nome)) &&
			(isset($email) && !empty($email)) &&
			(isset($senha) && !empty($senha)) &&
			(isset($confirmsenha) && !empty($confirmsenha)) &&
			(isset($nomeResponsavel) && !empty($nomeResponsavel)) &&
			(isset($cupom) && !empty($cupom)) &&
			(strcmp($senha, $confirmsenha) == 0)) {
				$alunos = new Alunos();
				$res_cadastro = $alunos->cadastro($nome, $email, $senha, $nomeResponsavel, $cupom);
				if($res_cadastro){
					$array = array();
					$_SESSION['sucess_cadastro'] = true;
					header("Location: ".BASE."/login");
				}
			}
			$array["erro_cadastro"] = "Dados inválidos. Confira suas informações e tente novamente.";
		}
		$this->loadView("cadastro", $array);
	}

	public function logout() {
		unset($_SESSION['lgaluno']);
		header("Location: ".BASE);
	}

}

