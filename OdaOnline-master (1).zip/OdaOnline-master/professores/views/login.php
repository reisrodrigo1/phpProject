<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo BASE; ?>/../assets/css/login.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/../assets/css/global.css">

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">



  <title>ODA Online</title>
</head>

<body>
  <form method="POST" class="form-signin">
    <img class=" img-logo" src="<?php echo BASE; ?>/../assets/images/cursos/logo-vertical.png" alt="Oficina Do Amanhã">

    <?php if (isset($err)) echo "<p class='err'>" . $err . "</p>" ?>

    <div class="form-group">
      <input type="email" id="inputEmail" name="email" class="form-input" placeholder="Email" required="true">
      <label for="inputEmail" class="form-label">Email</label>
    </div>

    <div class="form-group">
      <input type="password" id="inputPassword" class="form-input" placeholder="Senha" name="senha" required="true">
      <label for="inputPassword" class="form-label">Senha</label>
    </div>

    <div class="links">
      <div class="col">
        <a href="reset.html" class="form-link">Esqueci a Senha</a>
      </div>
    </div>


    <button class="btn btn-lg btn-primary btn-block botao" type="submit">
      Entrar
    </button>
  </form>




  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>

</html>