<?php
$curso_BASE = BASE . "/cursos/aula/";
$ids_aulas = array_column($aulas_modulo, 'id');
$ids_modulos = array_column($modulos, 'id');
$i = 0;

//pega o id do modulo atual no arrays de ids dos modulos
while (current($ids_modulos) != $aula_info2['id_modulo'])
	next($ids_modulos);

//pega o id da aula atual no arrays de ids das aulas
while (current($ids_aulas) != $aula_info['id_aula'])
	next($ids_aulas);

// Pega o index do array modulos
while ($modulos[$i]['id'] != current($ids_modulos)) {
	$i++;
}


function proximo($array_aulas, $base, $i, $modulos)
{
	if (next($array_aulas) != null) {
		$next = current($array_aulas);
		echo $base . $next;
	} else {
		if ($i == count($modulos) - 1) {
			echo "final do curso";
		} else {
			$i++;
			$next_modulos = $modulos[$i]['aulas'][0]['id'];
			echo $base . $next_modulos;
		}
	}
}

function anterior($array_aulas, $base, $i, $modulos)
{
	if (prev($array_aulas) != null) {
		$prev = current($array_aulas);
		echo $base . $prev;
	} else {
		if ($i == 0) {
			echo "final do curso";
		} else {
			$i--;
			$ultimo = count($modulos[$i]['aulas']) - 1;
			$next_modulos = $modulos[$i]['aulas'][$ultimo]['id'];
			echo $base . $next_modulos;
		}
	}
}

?>

<nav class="navbar">
	<div class="container-fluid">
		<div class="navbar-brand">

			<h3 class="titulo-quest-header">Questionário </h3>

		</div>
		<img src="<?php echo BASE; ?>/assets/images/cursos/<?php echo $curso->getImagem(); ?>" class="img" alt="foto">


		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon hamburguer">
				&nbsp;
			</span>
		</button>
	</div>
</nav>

<div class="collapse" id="toggler-menu">
	<div class="navigation-nav">
		<ul class="navigation-list">
			<!-- Como pegar o link dos cursos -->
			<li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
			<?php foreach ($cursos as $curso) : ?>
				<li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
			<?php endforeach; ?>
			<li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
		</ul>
	</div>
</div>

<div class="ellipse"></div>



<div class="container-fluid questionario" style="width: 75%;">
	<h3 class="pergunta"><?php echo $aula_info['pergunta']; ?></h3>
	<form method="POST">
		<div class="row">
			<div class="col">
				<input type="radio" name="opcao" value="1" id="opcao1" />
				<label for="opcao1" class="opcao"><?php echo $aula_info['opcao1']; ?></label><br /><br />

				<input type="radio" name="opcao" value="2" id="opcao2" />
				<label for="opcao2" class="opcao"><?php echo $aula_info['opcao2']; ?></label><br /><br />
			</div>
			<div class="col">
				<input type="radio" name="opcao" value="3" id="opcao3" />
				<label for="opcao3" class="opcao"><?php echo $aula_info['opcao3']; ?></label><br /><br />

				<input type="radio" name="opcao" value="4" id="opcao4" />
				<label for="opcao4" class="opcao"><?php echo $aula_info['opcao4']; ?></label><br /><br />
			</div>
		</div>

		<?php if ($aula_info['assistido'] == '1') : ?>
			<h2 class="botao">
				Este questionário já foi respondido!</h2>
		<?php else : ?>
			<input type="submit" class="botao botao-q" value="Enviar Resposta" />
		<?php endif; ?>
	</form>
	<?php if (isset($resposta)) : ?>
		<?php if ($resposta === true) : ?>
			<h3 class="resposta">RESPOSTA CORRETA!!</h3>
		<?php else :  ?>
			<h3 class="resposta">RESPOSTA INCORRETA!!</h3>
	<?php endif;
	endif; ?>
</div>
<div class="buttons">
	<div class="row">
		<div class="col">
			<form action="<?php anterior($ids_aulas, $curso_BASE, $i, $modulos) ?>">
				<input type="submit" value="< Anterior" class="botao" />
			</form>
		</div>
		<div class="col">
			<form action="<?php proximo($ids_aulas, $curso_BASE, $i, $modulos) ?>">
				<input type="submit" value="Próximo >" class="botao" />
			</form>

		</div>
	</div>
</div>


<div class="container-fluid" style="width: 75%;">
	<div class="lista-videos">
		<div class="accordion">
			<?php foreach ($modulos as $modulo) : ?>
				<div class="accordion-item">
					<h2 class="accordion-header">
						<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#id-<?php echo $modulo['id'] ?>">
							<div class="categoria">
								<?php echo $modulo['nome']; ?>
							</div>
						</button>
					</h2>
					<div id="id-<?php echo $modulo['id'] ?>" class="accordion-collapse collapse">
						<div class="accordion-body">
							<?php foreach ($modulo['aulas'] as $aula) : ?>
								<div class="accordion-conponent">
									<a href="<?php echo BASE; ?>/cursos/aula/<?php echo $aula['id']; ?>">
										<?php echo $aula['nome']; ?>
									</a>
								</div>
							<?php endforeach ?>

						</div>
					</div>
				</div>
			<?php endforeach; ?>


		</div>
	</div>

</div>