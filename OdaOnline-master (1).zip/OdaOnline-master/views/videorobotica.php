<div style="width:75%; height:75%; marg:in 0 auto; ">

	<div style="-webkit-box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);
-moz-box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);
box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);"  >
		<iframe  class="video" id="video" src="https://www.youtube.com/embed/1R8c2_-dz_E" ?>" allowfullscreen></iframe>
	</div>

</div>


