<div class="content">
        <div class="container-fluid">
          <!-- your content here -->

          <!-- Cards principais -->
          <div class="row">

            <div class="col-md-7">

              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">Adicionar Aluno</h4>
                  <p class="card-category">Insira os dados do aluno</p>
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="row">
                      <div class="col">
                        <div class="form-group has-info">
                          <label class="text-info">Nome</label>
                          <input type="text" class="form-control" name="nome">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col">
                        <div class="form-group has-info">
                          <label class="text-info">Email</label>
                          <input type="email" class="form-control" name="email">
                        </div>
                      </div>

                    </div>

                    <div class="row">
                      <div class="col">
                        <div class="form-group has-info">
                          <label class="text-info">Senha</label>
                          <input type="password" class="form-control" name="senha">
                        </div>
                      </div>
                    </div>

                    <button type="submit" class="btn btn-info pull-right">Adicionar</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>