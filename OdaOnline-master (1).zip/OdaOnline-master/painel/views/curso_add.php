      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-7">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Adicionar Oficina</h4>
                  <p class="card-category">Insira os dados da Oficina</p>
                </div>
                <div class="card-body">
                  <form method="POST" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                          <label class="  text-primary">Nome</label>
                          <input type="text" class="form-control" name="nome" value="">
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col">
                        <div class="form-group">
                          <label class="  text-primary">Descrição</label>
                          <textarea name="descricao" id="descricao" cols="30" rows="2" class="form-control"></textarea>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-md-6">
                        <div>
                          <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail img-raised">
                              <img src="<?php echo BASE ?>/../assets/images/cursos/logo-cinza.png" rel="nofollow" alt="...">
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                            <div>
                              <span class="btn btn-raised btn-round btn-default btn-file">
                                <span class="fileinput-new">Selecionar imagem</span>
                                <span class="fileinput-exists">Mudar</span>
                                <input type="hidden" value="" name="..."><input type="file" name="imagem">
                                <div class="ripple-container"></div>
                              </span>
                              <a href="#" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput">
                                <i class="fa fa-times"></i> Remover
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <button type="submit" class="btn btn-primary pull-right" value="Salvar">Salvar</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>