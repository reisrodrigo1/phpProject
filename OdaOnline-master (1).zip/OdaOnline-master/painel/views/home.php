<div class="content">
  <div class="container-fluid">

    <?php 
      if(isset($erro_live) || isset($scss_live)){
        if(isset($erro_live)){
          $texto = $erro_live;
          $cor = "danger";
        } else {
          $texto = $scss_live;
          $cor = "success";
        }
        echo <<<HTML
        <div class="alert alert-$cor alert-dismissible fade show" role="alert">
          <strong>$texto</strong>
          <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        HTML;
      }
    ?>

    <div class="row">
      <div class="col-lg-4 col-md-6 col-sm-6">
        <a href="<?php echo BASE; ?>/home/adicionar">
          <div class="card card-stats">
            <div class="card-header card-header-primary card-header-icon">
              <div class="card-icon">
                <i class="material-icons">add</i>
              </div>
              <p class="card-category">Cadastro de Oficina</p>
              <h3 class="card-title">Nova</h3>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">handyman</i> 7 oficinas cadastrados
              </div>
            </div>
          </div>
        </a>
      </div>

      <div class="col-lg-4 col-md-6 col-sm-6">
        <div class="card">
          <div class="card-header card-header-text card-header-success">
            <div class="card-text">
              <h4 class="card-title">Iniciar Live</h4>
            </div>
          </div>
          <div class="card-body">
            <form method="POST" action="<?php echo BASE?>/live">
              <div class="row">
                <div class="col-9">
                  <div class="form-group bmd-form-group has-success">
                    <input type="text" class="form-control" name="live-link" placeholder="https://">
                  </div>
                </div>
                <div class="col-3 special-btn-wrapper">
                  <button type="submit" class="btn btn-round btn-just-icon btn-success" value="Adicionar"><i class="material-icons">play_arrow</i></button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 col-sm-6">
        <a href="<?php echo BASE; ?>/live/encerrar">
          <div class="card card-stats">
            <div class="card-header card-header-danger card-header-icon">
              <div class="card-icon">
                <i class="material-icons">stop</i>
              </div>
              <p class="card-category">Live</p>
              <h3 class="card-title">Encerrar</h3>
            </div>
            <div class="card-footer">
              <div class="stats">
                <i class="material-icons">schedule</i> Iniciada às <strong>14:00</strong>
              </div>
            </div>
          </div>
        </a>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12">

        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Lista de Oficinas</h4>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover">
                <thead class="text-primary">
                  <tr>
                    <th>Imagem</th>
                    <th>Nome</th>
                    <th>Alunos Cadastrados</th>
                    <th class="text-center">Ações</th>
                  </tr>
                </thead>
                <tbody>

                  <?php foreach ($cursos as $curso) : ?>
                    <tr>
                      <td>
                        <img src="<?php echo BASE ?>/../assets/images/cursos/<?php echo $curso['imagem'] ?>" height="70" border="0">
                      </td>
                      <td><?php echo $curso['nome']; ?></td>
                      <td width="80"><?php echo $curso['qtalunos'] ?></td>
                      <td class="td-actions text-center">

                        <button type="button" rel="tooltip" class="btn btn-success btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/home/editar/<?php echo $curso['id']; ?>';">
                          <i class="material-icons">edit</i>
                        </button>
                        <button type="button" rel="tooltip" class="btn btn-danger btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/home/excluir/<?php echo $curso['id']; ?>';">
                          <i class="material-icons">close</i>
                        </button>
                      </td>
                    </tr>
                  <?php endforeach; ?>



                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>