      <div class="content">
        <div class="container-fluid">

          <!-- Cards principais -->

          <div class="row">

            <div class="col-lg-4 col-md-6 col-sm-6">
              <a href="<?php echo BASE; ?>/alunos/adicionar">
                <div class="card card-stats">
                  <div class="card-header card-header-info card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons">add</i>
                    </div>
                    <p class="card-category">Cadastro de Alunos</p>
                    <h3 class="card-title">Novo</h3>
                  </div>
                  <div class="card-footer">
                    <div class="stats">
                      <i class="material-icons">people</i> 37 alunos cadastrados 
                    </div>
                  </div>
                </div>
              </a>
            </div>

          </div>

          <div class="row">

            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">Lista de Alunos</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class="text-info">
                        <tr>
                          <th>Nome</th>
                          <th>Qt. de Cursos</th>
                          <th class="td-actions text-center">Ações</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php foreach($alunos as $aluno):?>  
                        <tr>
                          <td><?php echo $aluno['nome']?></td>
                          <td><?php echo $aluno['qtcursos']?></td>
                          <td class="td-actions text-center">
                            <button type="button" rel="tooltip" class="btn btn-success btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/alunos/editar/<?php echo $aluno['id']; ?>';">
                              <i class="material-icons">edit</i>
                            </button>
                            <button type="button" rel="tooltip" class="btn btn-danger btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/alunos/excluir/<?php echo $aluno['id']; ?>';">
                              <i class="material-icons">close</i>
                            </button>
                          </td>
                        <?php endforeach; ?>

                        </tr>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

          </div>



        </div>
      </div>