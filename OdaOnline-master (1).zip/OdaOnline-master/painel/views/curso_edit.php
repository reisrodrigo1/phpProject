      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Editar Oficina</h4>
                  <p class="card-category">Atualize os dados da Oficina</p>
                </div>
                <div class="card-body">
                  <form method="POST" enctype="multipart/form-data">
                    <div class="row">

                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="  text-primary">Nome</label>
                          <input type="text" class="form-control" name="nome" value="<?php echo $curso['nome'] ?>">
                        </div>
                      </div>

                      <div class="col-md-7">
                        <div class="form-group">
                          <label class="  text-primary">Descrição</label>
                          <input type="text" class="form-control" name="descricao" value="<?php echo $curso['descricao'] ?>">
                        </div>
                      </div>

                    </div>

                    <div class="row">
                      <div class="col-md-6">
                        <div class="bd-example" data-example-id="">
                          <div class="fileinput text-center fileinput-new" data-provides="fileinput">
                            <div class="fileinput-new thumbnail img-raised">
                              <img src="<?php echo BASE; ?>/../assets/images/cursos/<?php echo $curso['imagem'] ?>" rel="nofollow" alt="...">
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                            <div>
                              <span class="btn btn-raised btn-round btn-default btn-file">
                                <span class="fileinput-new">Selecionar imagem</span>
                                <span class="fileinput-exists">Mudar</span>
                                <input type="hidden" value="" name="..."><input type="file" name="imagem">
                                <div class="ripple-container"></div>
                              </span>
                              <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput">
                                <i class="fa fa-times"></i> Remover
                              </a>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>





                    <button type="submit" class="btn btn-primary pull-right" value="Salvar">Salvar</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-lg-8">
              <div class="card">
                <div class="card-header card-header-text card-header-primary">
                  <div class="card-text">
                    <h4 class="card-title">Adicionar Aula</h4>
                  </div>
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="row">

                      <div class="col-md-6">
                        <div class="form-group bmd-form-group">
                          <label class="text-primary">Título</label>
                          <input type="text" class="form-control" name="aula">
                        </div>
                      </div>

                      <div class="form-group col-md-6">
                        <h5 class="text-primary special-label">Módulo</h5>
                        <?php foreach ($modulos as $modulo) : ?>
                          <div class="form-check form-check-radio">
                            <label class="form-check-label">
                              <input class="form-check-input" type="radio" name="moduloaula" id="moduloaula" value="<?php echo $modulo['id']; ?>">
                              <?php echo $modulo['nome']; ?>
                              <span class="circle">
                                <span class="check"></span>
                              </span>
                            </label>
                          </div>
                        <?php endforeach ?>
                      </div>

                      <div class="form-group col-10">
                        <h5 class="text-primary special-label">Tipo da Aula</h5>
                        <div class="form-check form-check-radio">
                          <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="tipo" id="tipo" value="video">
                            Vídeo
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div>
                        <div class="form-check form-check-radio">
                          <label class="form-check-label">
                            <input class="form-check-input" type="radio" name="tipo" id="tipo" value="poll">
                            Questionário
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div>
                      </div>

                      <div class="col-2 special-btn-wrapper">
                        <button type="submit" class="btn btn-round btn-just-icon btn-primary" value="Adicionar"><i class="material-icons">add</i></button>
                      </div>

                    </div>

                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-4">
              <div class="card">
                <div class="card-header card-header-text card-header-success">
                  <div class="card-text">
                    <h4 class="card-title">Adicionar Módulo</h4>
                  </div>
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="row">
                      <div class="col-9">
                        <div class="form-group bmd-form-group has-success">
                          <label class="text-success">Nome</label>
                          <input type="text" class="form-control" name="modulo">
                        </div>
                      </div>
                      <div class="col-3 special-btn-wrapper">
                        <button type="submit" class="btn btn-round btn-just-icon btn-success" value="Adicionar"><i class="material-icons">add</i></button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

          <div class="row">

            <?php foreach ($modulos as $modulo) : ?>
              <div class="col-lg-6 col-md-12">
                <div class="card">
                  <div class="card-header card-header-success">
                    <h3 class="card-title"><?php echo $modulo['nome'] ?></h3>
                    <div class="pull-right">
                      <button type="button" rel="tooltip" class="btn btn-info btn-just-icon btn-round btn-sm" onclick="window.location.href = '<?php echo BASE; ?>/home/edit_modulo/<?php echo $modulo['id']; ?>';">
                        <i class="material-icons">edit</i>
                      </button>
                      <button type="button" rel="tooltip" class="btn btn-danger btn-just-icon btn-round btn-sm" onclick="window.location.href = '<?php echo BASE; ?>/home/del_modulo/<?php echo $modulo['id']; ?>';">
                        <i class="material-icons">close</i>
                      </button>
                    </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-hover">
                        <?php foreach ($modulo['aulas'] as $aula) : ?>
                          <tr>
                            <td><?php echo $aula['nome']; ?></td>
                            <td class="td-actions text-right">
                              <button type="button" rel="tooltip" class="btn btn-success btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/home/edit_aula/<?php echo $aula['id']; ?>';">
                                <i class="material-icons">edit</i>
                              </button>
                              <button type="button" rel="tooltip" class="btn btn-danger btn-simple" onclick="window.location.href = '<?php echo BASE; ?>/home/del_aula/<?php echo $aula['id']; ?>';">
                                <i class="material-icons">close</i>
                              </button>
                            </td>
                          </tr>
                        <?php endforeach; ?>
                      </table>

                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>