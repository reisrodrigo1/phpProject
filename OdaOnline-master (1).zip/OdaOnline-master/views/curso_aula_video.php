<?php
$curso_BASE = BASE . "/cursos/aula/";
$ids_aulas = array_column($aulas_modulo, 'id');
$ids_modulos = array_column($modulos, 'id');
$i = 0;

//pega o id do modulo atual no arrays de ids dos modulos
while (current($ids_modulos) != $aula_info2['id_modulo'])
	next($ids_modulos);

//pega o id da aula atual no arrays de ids das aulas
while (current($ids_aulas) != $aula_info['id_aula'])
	next($ids_aulas);

// Pega o index do array modulos
while ($modulos[$i]['id'] != current($ids_modulos)) {
	$i++;
}

function proximo($array_aulas, $base, $i, $modulos)
{
	if (next($array_aulas) != null) {
		$next = current($array_aulas);
		echo $base . $next;
	} else {
		if ($i == count($modulos) - 1) {
			echo "final do curso";
		} else {
			$i++;
			$next_modulos = $modulos[$i]['aulas'][0]['id'];
			echo $base . $next_modulos;
		}
	}
}

function anterior($array_aulas, $base, $i, $modulos)
{
	if (prev($array_aulas) != null) {
		$prev = current($array_aulas);
		echo $base . $prev;
	} else {
		if ($i == 0) {
			echo "final do curso";
		} else {
			$i--;
			$ultimo = count($modulos[$i]['aulas']) - 1;
			$next_modulos = $modulos[$i]['aulas'][$ultimo]['id'];
			echo $base . $next_modulos;
		}
	}
}
?>

<nav class="navbar">
	<div class="container-fluid">
		<div class="navbar-brand">

			<h3 class="titulo"><?php echo $aula_info2['nome']; ?></h3>
			<h4 class="subtitulo"><?php echo $aula_info['nome']; ?></h4>

		</div>
		<img src="<?php echo BASE; ?>/assets/images/cursos/<?php echo $curso->getImagem(); ?>" class="img" alt="foto">

		<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon hamburguer">
				&nbsp;
			</span>
		</button>
	</div>
</nav>

<div class="collapse" id="toggler-menu">
	<div class="navigation-nav">
		<ul class="navigation-list">
			<!-- Como pegar o link dos cursos -->
			<li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
			<?php foreach ($cursos as $curso) : ?>
				<li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
			<?php endforeach; ?>
			<li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
			<li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
			<li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
		</ul>
	</div>
</div>

<div class="ellipse"></div>

<div class="container-fluid">

	<div class="container-video" style="width: 75%; ">
		<iframe class="video" id="video" src="<?php echo $aula_info['url']; ?>" allowfullscreen></iframe>
	</div>


	<div class="buttons">
		<div class="row">
			<div class="col">
				<form action="<?php anterior($ids_aulas, $curso_BASE, $i, $modulos) ?>">
					<input type="submit" value="< Anterior" class="botao" />
				</form>
			</div>
			<div class="col">
				<?php if ($aula_info['assistido'] == '1') : ?>
					<h3 class="botao">
						Esta aula já foi assistida!
					</h3>
				<?php else : ?>

					<button class="botao" onclick="marcarAssistido(this)" data-id="<?php echo $aula_info['id_aula']; ?>">
						Marcar como assistido
					</button>
				<?php endif; ?>
			</div>
			<div class="col">
				<form action="<?php proximo($ids_aulas, $curso_BASE, $i, $modulos) ?>">
					<input type="submit" value="Próximo >" class="botao" />
				</form>

			</div>
		</div>
	</div>

	<div class="ellipse"></div>

	<div class="comentario">
		<form method="POST" class="form_duvida">
			<label for="duvidatext" class="comentario-titulo">Alguma dúvida? Deixe um comentário:</label>
			<textarea id="duvidatext" class="comentario-text form-control" placeholder="Escreva aqui.."></textarea>
			<input type="submit" value="Enviar Dúvida" class="botao-duvida" />
		</form>
	</div>

	<div class="ellipse"></div>
</div>

<div class="container-fluid" style="width: 75%;">
	<div class="lista-videos">
		<div class="accordion">
			<?php foreach ($modulos as $modulo) : ?>
				<div class="accordion-item">
					<h2 class="accordion-header">
						<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#id-<?php echo $modulo['id'] ?>">
							<div class="categoria">
								<?php echo $modulo['nome']; ?>
							</div>
						</button>
					</h2>
					<div id="id-<?php echo $modulo['id'] ?>" class="accordion-collapse collapse">
						<div class="accordion-body">
							<?php foreach ($modulo['aulas'] as $aula) : ?>
								<div class="accordion-conponent">
									<a href="<?php echo BASE; ?>/cursos/aula/<?php echo $aula['id']; ?>">
										<?php echo $aula['nome']; ?>
									</a>
								</div>
							<?php endforeach ?>

						</div>
					</div>
				</div>
			<?php endforeach; ?>


		</div>
	</div>

</div>