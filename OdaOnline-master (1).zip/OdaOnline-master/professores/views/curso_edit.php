<h1>Editar Oficina</h1>


      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Editar Oficina</h4>
                  <p class="card-category">Atualize os dados da Oficina</p>
                </div>
                <div class="card-body">
                  <form  method="POST" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Nome</label>
                          <input type="text" class="form-control" name="nome" value="<?php echo $curso['nome']; ?>" >
                     
                        </div>
                      </div>

                      <div class="col-md-7">
                        <div class="form-group">
                          <label class="bmd-label-floating">Descrição</label>
                          <input type="text" class="form-control" name="email" value="<?php echo $curso['descricao']; ?>">

                        </div>
                      </div>
              
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        Imagem:<br/>
	<input type="file" name="imagem" /><br/>
	<img src="<?php echo BASE; ?>../assets/images/cursos/<?php echo $curso['imagem']; ?>" border="0" height="80" /><br/><br/>
	
                      </div>

                    </div>
                    <button type="submit" class="btn btn-primary pull-right" type="submit" value="Salvar">Salvar</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
        </div>
        </div>


<hr/>

<h2>Aulas</h2>




	        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Adicionar Aula Nova</h4>
                  <p class="card-category">Atualize os dados da Oficina</p>
                </div>
                <div class="card-body">
                  <form  method="POST" >
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group">
                          <label class="bmd-label-floating">Titulo da aula</label>
                          <input type="text" class="form-control" name="aula"  >
                     
                        </div>
                      </div>
            
              
              
                   
                      	<div class="col-md-7">
Módulo da aula<br/>
	<select multiple class="form-control" id="exampleFormControlSelect2" name="moduloaula" multiple style="height:120px">
		<?php foreach($modulos as $modulo): ?>
			<option value="<?php echo $modulo['id']; ?>"><?php echo utf8_encode($modulo['nome']); ?></option>
			<?php endforeach; ?>
	</select><br/><br/>
</div>
</div>
<div class="row">
                   
                      	<div class="col-md-12">

Tipo da aula:<br/>
		<select name="tipo"  multiple class="form-control" id="exampleFormControlSelect2" style="height:60px"><br>
			<option value="video">Vídeo</option>
			<option value="poll">Questionário</option>
		</select><br/><br/><br/><br/>
</div>


</div>
                    </div>
                 
                    <button type="submit" class="btn btn-primary pull-right"  value="Adicionar Aula" >Salvar</button>
                    <div class="clearfix"></div>
                  </form>
                </div>
              </div>
            </div>
            
        </div>
        </div>
</fieldset><br/>

<?php foreach($modulos as $modulo): ?>

	<h4><?php echo utf8_encode($modulo['nome']); ?> - <a href="<?php echo BASE; ?>home/edit_modulo/<?php echo $modulo['id']; ?>">[editar]</a> - <a href="<?php echo BASE; ?>home/del_modulo/<?php echo $modulo['id']; ?>">[excluir]</a></h4>

	<?php foreach($modulo['aulas'] as $aula): ?>
	<h5><?php echo $aula['nome']; ?> - <a href="<?php echo BASE; ?>home/edit_aula/<?php echo $aula['id']; ?>">[editar]</a> - <a href="<?php echo BASE; ?>home/del_aula/<?php echo $aula['id']; ?>">[excluir]</a></h5>
	<?php endforeach; ?>


<?php endforeach; ?>



</div>






