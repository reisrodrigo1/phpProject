<?php
class Lives extends model {

    public function isOn(){
        // Checa se alguma live está aberta nesse momento

        // aberta = live com fim NULL

        $sql = $this->db->query("SELECT * FROM lives WHERE fim IS null;");
        if($sql->fetch()){
            return true;
        }
        return false;
    }
    
    public function getURLAtual() {
        // Retorna a url da live atual

        $sql = $this->db->query("SELECT url FROM lives WHERE fim IS null;");

        $row = $sql->fetch();

        return $row["url"];
    }
}

?>