<div class="content">
  <div class="row">

    <div class="col-md-9 col-lg-8">

      <div class="card">
        <div class="card-header card-header-danger">
          <h4 class="card-title">Editar Aula</h4>
          <p>Questionário</p>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="row">
              <div class="col-12">
                <div class="form-group has-danger">
                  <label for="pergunta">Pergunta</label>
                  <input type="text" class="form-control" name="pergunta" value="<?php echo $aula['pergunta']; ?>">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group has-danger">
                  <label for="opcao1">Opção 1</label>
                  <input type="text" class="form-control" name="opcao1" value="<?php echo $aula['opcao1']; ?>">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group has-danger">
                  <label for="opcao2">Opção 2</label>
                  <input type="text" class="form-control" name="opcao2" value="<?php echo $aula['opcao2']; ?>">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group has-danger">
                  <label for="opcao3">Opção 3</label>
                  <input type="text" class="form-control" name="opcao3" value="<?php echo $aula['opcao3']; ?>">
                </div>
              </div>
              <div class="col-sm-6">
                <div class="form-group has-danger">
                  <label for="opcao4">Opção 4</label>
                  <input type="text" class="form-control" name="opcao4" value="<?php echo $aula['opcao4']; ?>">
                </div>
              </div>
              
            </div>
            
            <div class="form-group">
              <h4 class="text-danger special-label">Resposta Correta</h4>
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="resposta" value="1" <?php echo ($aula['resposta']=='1')?'checked':''; ?>> 1
                  <span class="circle special-border-red">
                      <span class="check special-color-red"></span>
                  </span>
                </label>
              </div>
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="resposta" value="2" <?php echo ($aula['resposta']=='2')?'checked':''; ?>> 2
                  <span class="circle special-border-red">
                      <span class="check special-color-red"></span>
                  </span>
                </label>
              </div>
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="resposta" value="3" <?php echo ($aula['resposta']=='3')?'checked':''; ?>> 3
                  <span class="circle special-border-red">
                      <span class="check special-color-red"></span>
                  </span>
                </label>
              </div>
              <div class="form-check form-check-radio form-check-inline">
                <label class="form-check-label">
                  <input class="form-check-input" type="radio" name="resposta" value="4" <?php echo ($aula['resposta']=='4')?'checked':''; ?>> 4
                  <span class="circle special-border-red">
                      <span class="check special-color-red"></span>
                  </span>
                </label>
              </div>
            </div>

            <button type="submit" class="btn btn-danger pull-right">Salvar</button>
          </form>
        </div>
      </div>

    </div>

  </div>
</div>
