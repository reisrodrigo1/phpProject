
<div class="content">
  <div class="row">

    <div class="col-md-7">

      <div class="card">
        <div class="card-header card-header-danger">
          <h4 class="card-title">Editar Aula</h4>
          <p class="card-description">Vídeo</p>
        </div>
        <div class="card-body">
          <form method="POST">
            <div class="form-group has-danger">
              <label class=" ">Título</label>
              <input type="text" class="form-control" name="nome" value="<?php echo $aula['nome']; ?>" />
            </div>
            <div class="form-group has-danger">
              <label class=" ">Descrição</label>
              <textarea name="descricao" id="descricao" cols="30" rows="2" class="form-control"><?php echo $aula['descricao']; ?></textarea>
            </div>
            <div class="form-group has-danger">
              <label class=" ">URL do Vídeo</label>
              <input type="text" class="form-control" name="url" value="<?php echo $aula['url']; ?>">
            </div>

            <button type="submit" class="btn btn-danger pull-right">Salvar</button>
          </form>
        </div>
      </div>

    </div>

  </div>
</div>