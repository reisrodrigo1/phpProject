<?php
class recuperarController extends controller
{

     public function __construct()
     {
          parent::__construct();
     }

     public function index()
     {
          $array = array();

          if(isset($_POST['email']) && !empty($_POST['email'])) {

               $email = $_POST['email'];
			$alunos = new Alunos();
               $senhas = new Senhas();
          
               if($alunos->getEmailsAlunos($email) == 0){ //nao existir no banco
                   $array['err_email'] = "Email não existe";
               } else {
                    $rash = md5(rand());
                    $senhas->addRecuperaSenha($email, $rash);

                    $this->enviar_email($email, $rash);

                    $array['suc_email'] = "Link enviado para seu Email";
                    $senhas->redirecionar(BASE, 4);
               }
		}

          $this->loadView('recuperar', $array);
     }

     public function enviar_email($email, $rash){
          $destinatario = $email;
          $remetente = "Oficina do Amanhã <no-reply@odaonline.com.br>";
          
          $subject = "Alterar sua Senha";
          $headers = "MIME-Version: 1.0\r\n";
          $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
          $headers .= 'From: ' . $remetente;
          


          $message = "<html>
          <body style='background-color: #53517a; text-align: center; padding: 20px 0;background-image: url(https://odaonline.com.br/assets/images/fundo.png);'>
               
               <div style='background-color: #58c6d0e6;
                    width: max-content;
                    padding: 20px 30px;
                    border-radius: 15px;
                    margin: 20px auto;'>

                    <h1 style='color: #53517a;
                         margin-bottom: 60px;'>
                              Foi solicitada a<br> mudança de sua senha.
                    </h1>
                    <p style='font-size: 22px;'>
                         Se foi você que solicitou, por favor<br> clique no botão a seguir para alterar a senha:
                    </p>
                    <a href='". BASE ."/recuperar/alterar/{$rash}'>
                         <button style='border: none;
                                   background-color: #53517a;
                                   border-radius: 10px;
                                   color: white;
                                   padding: 10px 15px;
                                   font-size: 22px;
                                   margin: 15px 0;
                                   cursor: pointer;'>
                                        Mudar Senha
                         </button>
                    </a>
                    <p style='font-size: 22px;'>
                         Se você não solicitou nenhuma alteração,<br> por favor ignore esse email.</p>
                    <br>
                    <img src='https://odaonline.com.br/assets/images/cursos/logo-vertical.png' width='150px'>
               </div>   
          </body> 
         </html>";

          if(mail($destinatario, $subject, $message, $headers)){
			return true;
          } else {
               echo "Erro ao enviar email";
          }

     }

     public function alterar($rash)
     {
          $array = array();
          $senhas = new Senhas();
      
          if(isset($_POST['env']) && $_POST['env'] == 'upd'){
               if(strcmp($_POST['senha'], $_POST['confirmsenha']) == 0){
                    if($senhas->verifica_rash($rash) > 0 ){
                         $nova_senha = md5($_POST['senha']);
     
                         $senhas->atualiza_senha($rash, $nova_senha);
                         $senhas->deleta_rash($rash);

                         $array['suc_senha'] = "Senha alterada com sucesso!!";
                         $senhas->redirecionar(BASE,3);
     
                    }else{
                         $array['err_senha'] = "Formulário inválido, tente reenviar email de troca de senha";
                    }
               } else {
                    $array['err_senha'] = "Senhas diferentes";
               }         
          }         
          
          $this->loadView('alterar', $array);
     }
}