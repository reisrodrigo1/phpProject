<?php
class Core {

	public function run() {
		// Trata tanto amb de desenvolvimento quanto end. '/professores' em ambos os ambientes
		$url = explode('/professores', $_SERVER['REQUEST_URI']);
		$url = end($url);

		$params = array();

		if($url != '/') {
			// Caso em que nao está na página principal (URI != '/')

			// $url = '/controller/method/params...'

			$url = explode('/', $url);
			array_shift($url); //retira string vazia de antes da /

			// Primeira posicao => controller
			$currentController = $url[0].'Controller';
			array_shift($url);

			// Proxima posicao, se tiver => metodo

			if(isset($url[0])) {
				$currentAction = $url[0];
				array_shift($url);
			} else {
				// Metodo padrao caso nao esteja na uri
				$currentAction = 'index';
			}

			// Se houver mais coisa na uri, coloca no array de $params

			if(count($url) > 0) {
				$params = $url;
			}

		} else {
			// Caso em que esta na pagina principal (URI == '/')

			$currentController = 'homeController';
			$currentAction = 'index';
		}

		$c = new $currentController();
		call_user_func_array(array($c, $currentAction), $params);

	}

}