<?php
class Cursos extends model {

	private $info;

	public function getCursosDoAluno($id) {
		$array = array();

		$sql = "
			SELECT 
				aluno_curso.id_curso,
				cursos.nome,
				cursos.imagem,
				cursos.descricao
			FROM 
				aluno_curso
			LEFT JOIN cursos
				ON aluno_curso.id_curso = cursos.id
			WHERE
				aluno_curso.id_aluno = :id
		";
		
		$stmt = $this->db->prepare($sql);
		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetchAll();
		}

		return $array;
	}

	public function getCursosDoAluno2($id) {
		$array = array();

		$sql = "
				SELECT *
			    FROM cursos
			    WHERE cursos.id NOT IN
			           (SELECT DISTINCT
			                 cursos.id 
			            FROM 
			                 cursos 
			             INNER JOIN 
			             aluno_curso
			             on aluno_curso.id_curso = cursos.id WHERE aluno_curso.id_aluno = :id )
		";

		$stmt = $this->db->prepare($sql);
		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetchAll();
		}

		return $array;
	}

	public function setCurso($id) {
		$stmt = $this->db->prepare("SELECT * FROM cursos WHERE id = :id");
		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$this->info = $stmt->fetch();
		}
	}

	public function getNome() {
		return $this->info['nome'];
	}

	public function getImagem() {
		return $this->info['imagem'];
	}

	public function getDescricao() {
		return $this->info['descricao'];
	}

	public function getId() {
		return $this->info['id'];
	}

	public function getTotalAulas() {
		$stmt = $this->db->prepare("SELECT id FROM aulas WHERE id_curso = :id");
		
		$id_curso = $this->getId();
		$stmt->bindParam(':id', $id_curso);
		$stmt->execute();

		return $stmt->rowCount();
	}

}
?>