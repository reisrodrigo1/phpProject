  <div class="content">

  <div class="container-fluid">
          <div class="row">

            <div class="card">
              
              <div class="card-header card-header-primary">
                <h3 class="card-title ">Adicionar Oficina</h3>
                <p class="card-category">Preencha os dados referentes à oficina dada</p>
              </div>

              <div class="card-body">
				<form method="POST" enctype="multipart/form-data">
                    
                  <div class="form-group has-primary">
                    <label class="bmd-label-floating" for="nome">Professor</label>
                    <input class="form-control" type="text" name="nome" id="nome">
                  </div>

                  <div class="form-row">
                    <div class="form-group col-md-6">
                      <label class="bmd-label-floating" for="oficina">Oficina</label>
                      <input class="form-control" type="text" name="oficina" id="oficina">
                    </div>
        
                    <div class="form-group col-md-6">
                      <label class="bmd-label-floating" for="aula">Aula</label>
                      <input class="form-control" type="text" name="aula" id="aula">
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="form-group col-md-8">
                      <label class="bmd-label-floating" for="projeto">Projeto</label>
                      <input class="form-control" type="text" name="projeto" id="projeto">
                    </div>

                    <div class="form-group col-md-4">
                      <label class="bmd-label-floating" for="data">Data</label>
                      <input class="form-control" type="date" name="data" id="data">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="bmd-label-floating" for="descricao">Descrição</label>
                    <textarea class="form-control" name="descricao" id="descricao" rows="5"></textarea>
                  </div>
                  
                  <button type="submit" class="btn btn-primary pull-right">
                    Adicionar
                  </button>
                
                </form>
              </div>
            </div>
        </div>
    </div>