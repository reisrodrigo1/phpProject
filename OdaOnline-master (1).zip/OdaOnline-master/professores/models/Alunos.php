<?php
class Alunos extends model {

	public function getAlunos() {
		$array = array();

		$sql = "SELECT 
			*,
			(select count(*) from aluno_curso where aluno_curso.id_aluno = alunos.id) as qtcursos 
			FROM alunos";
		$sql = $this->db->query($sql);

		if($sql->rowCount() > 0) {
			$array = $sql->fetchAll();
		}

		return $array;
	}

	public function getNumAlunos() {
		$sql = "SELECT id FROM alunos";
		$sql = $this->db->query($sql);

		return $sql->rowCount();
	}

	public function setUsuarios($id) {
		$stmt = $this->db->prepare("SELECT * FROM usuarios WHERE id = :id");

		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$this->info = $stmt->fetch();
		}
	}

	/* public function getNumAlunosRobotica() {

		$sql = "SELECT id FROM aluno_curso WHERE id_curso = '1'";
		$sql = $this->db->query($sql);

		return $sql->rowCount();
	} */
	
	/* public function getNumAlunosProgramacao() {

		$sql = " SELECT id FROM aluno_curso WHERE id_curso = '2' ";
		$sql = $this->db->query($sql);

		return $sql->rowCount();
	} */
	
	/* public function getNumAlunosOdapad() {

		$sql = " SELECT id FROM aluno_curso WHERE id_curso = '3' ";
		$sql = $this->db->query($sql);

		return $sql->rowCount();
	} */

	public function getAluno($id) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM alunos WHERE id = :id");

		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetch();
		}

		return $array;
	}

	public function deleteAluno($id) {
		$stmt = $this->db->prepare("DELETE FROM alunos WHERE id = :id");
		$stmt->bindParam(':id', $id);
		$stmt->execute();
	}

	public function addAluno($nome, $email, $senha) {
		$stmt = $this->db->prepare("INSERT INTO alunos SET nome = :nome, email = :email, senha = :senha");

		$stmt->bindParam(':nome', $nome);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':senha', $senha);
		$stmt->execute();
	}

	public function updateAluno($id, $nome, $email, $cursos) {
		$stmt = $this->db->prepare("UPDATE alunos SET nome = :nome, email = :email, WHERE id = :id");

		$stmt->bindParam(':nome', $nome);
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		
		$stmt = $this->db->prepare("DELETE FROM aluno_curso WHERE id_aluno = :id");
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		
		
		foreach($cursos as $curso) {
			$stmt = $this->db->prepare("INSERT INTO aluno_curso SET id_aluno = :id, id_curso = :curso");
			
			$stmt->bindParam(':id', $id);
			$stmt->bindParam(':curso', $curso);
			$stmt->execute();
		}
	}

}
?>