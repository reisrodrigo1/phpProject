
      <div class="content">
        <div class="container-fluid">
          <div class="row">

            <div class="col-md-12">

              <div class="card">
                <div class="card-header card-header-info">
                  <h4 class="card-title">Editar Aluno</h4>
                  <p class="card-category">Atualize os dados do aluno</p>
                </div>
                <div class="card-body">
                  <form method="POST">
                    <div class="row">
                      <div class="col-md-5">
                        <div class="form-group has-info">
                          <label class="text-info">Nome</label>
                          <input type="text" class="form-control" name="nome" value="<?php echo $aluno['nome']?>">
                        </div>
                      </div>
                      <div class="col-md-7">
                        <div class="form-group has-info">
                          <label class="text-info">Email</label>
                          <input type="text" class="form-control" name="email" value="<?php echo $aluno['email']?>">
                        </div>
                      </div>

                    </div>
                    <div class="row">
                      <!-- <div class="col-md-6">
                        <div class="form-group has-info">
                          <label class="text-info">Senha</label>
                          <input type="text" class="form-control" name="senha" value="<?php echo $aluno['senha']?>">
                        </div>
                      </div> -->


                      <div class="col-md-6">
                        <h4 class="text-info special-label">Cursos inscritos:</h4>

                        <div class="form-group has-info">
                          <?php foreach($cursos as $curso) : ?>
                          <div class="form-check mx-2">
                            <label class="form-check-label">
                                <input class="form-check-input" type="checkbox" name="cursos[]" value="<?php echo $curso['id']?>" <?php if(in_array($curso['id'], $inscrito)){echo 'checked';}?>>
                                <p class="text-dark m-0">
                                  <?php echo $curso['nome']?>
                                </p>
                                <span class="form-check-sign">
                                    <span class="check special-color-info"></span>
                                </span>
                            </label>
                          </div>
                          <?php endforeach;?>
                        </div>
                      </div>

                    </div>

                    <button type="submit" class="btn btn-info pull-right" value="Salvar">Salvar</button>
                  </form>
                </div>
              </div>

            </div>

          </div>



        </div>
      </div>
