<?php
class Aulas extends model {

	public function getAulasDoModulo($id) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM aulas WHERE id_modulo = :id ORDER BY ordem");

		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetchAll();

			foreach($array as $aulachave => $aula) {
				if($aula['tipo'] == 'video') {
					$stmt = $this->db->prepare("SELECT nome FROM videos WHERE id_aula = :id_aula");

					$stmt->bindParam(':id_aula', $aula['id']);
					$stmt->execute();

					$row = $stmt->fetch();

					$array[$aulachave]['nome'] = $row['nome'];
				}
				elseif($aula['tipo'] == 'poll') {
					$array[$aulachave]['nome'] = "Questionário";
				}
			}
		}

		return $array;
	}

	public function deleteAula($id) {
		$stmt = $this->db->prepare("SELECT id_curso FROM aulas WHERE id = :id");

		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			
			$stmt = $this->db->prepare("DELETE FROM aulas WHERE id = ?");
			$stmt->execute([$id]);

			return $row['id_curso'];
		}
	}

	public function addAula($id_curso, $id_modulo, $nome, $tipo) {
		$stmt = $this->db->prepare("SELECT ordem FROM aulas WHERE id_modulo = ? ORDER BY ordem DESC LIMIT 1");
		$stmt->execute([$id_modulo]);

		$ordem = 1;
		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			$ordem = intval($row['ordem']);
			$ordem++;
		}

		$stmt = $this->db->prepare("INSERT INTO aulas SET id_modulo = :id_modulo, id_curso = :id_curso, ordem = :ordem, tipo = :tipo");

		$stmt->bindParam(':id_modulo', $id_modulo);
		$stmt->bindParam(':id_curso', $id_curso);
		$stmt->bindParam(':ordem', $ordem);
		$stmt->bindParam(':tipo', $tipo);
		$stmt->execute();

		$id_aula = $this->db->lastInsertId();

		if($tipo == 'video') {
			$stmt = $this->db->prepare("INSERT INTO videos SET id_aula = :id_aula, nome = :nome");
			$stmt->bindParam(':nome', $nome);
		} else {
			$stmt = $this->db->prepare("INSERT INTO questionarios SET id_aula = :id_aula");
		}

		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();
	}

	public function getAula($id_aula) {
		$array = array();

		$stmt = $this->db->prepare("SELECT tipo FROM aulas WHERE id = :id_aula");

		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();

			if($row["tipo"] == 'video') {
				$stmt = $this->db->prepare("SELECT * FROM videos WHERE id_aula = :id_aula");
			} elseif($row["tipo"] == "poll") {
				$stmt = $this->db->prepare("SELECT * FROM questionarios WHERE id_aula = :id_aula");
			}
			
			$stmt->bindParam(':id_aula', $id_aula);
			$stmt->execute();
			
			$array = $stmt->fetch();
			$array["tipo"] = $row["tipo"];

		}
		return $array;
	}

	public function updateVideoAula($id, $nome, $descricao, $url) {
		$stmt = $this->db->prepare("UPDATE videos SET nome = :nome, descricao = :descricao, url = :url WHERE id_aula = :id");

		$stmt->bindParam(":nome", $nome);
		$stmt->bindParam(":descricao", $descricao);
		$stmt->bindParam(":url", $url);
		$stmt->bindParam(":id", $id);
		$stmt->execute();

		return $this->getCursoDeAula($id);
	}

	public function updateQuestionarioAula($id, $pergunta, $opcao1, $opcao2, $opcao3, $opcao4, $resposta) {
		$sql = "UPDATE questionarios
				SET pergunta = :pergunta, opcao1 = :opcao1, opcao2 = :opcao2,
				opcao3 = :opcao3, opcao4 = :opcao4, resposta = :resposta
				WHERE id_aula = :id";
		$stmt = $this->db->prepare($sql);

		$stmt->bindParam(":pergunta", $pergunta);
		$stmt->bindParam(":opcao1", $opcao1);
		$stmt->bindParam(":opcao2", $opcao2);
		$stmt->bindParam(":opcao3", $opcao3);
		$stmt->bindParam(":opcao4", $opcao4);
		$stmt->bindParam(":resposta", $resposta);
		$stmt->bindParam(":id", $id);

		$stmt->execute();

		return $this->getCursoDeAula($id);
	}

	public function getCursoDeAula($id_aula) {
		$stmt = $this->db->prepare("SELECT id_curso FROM aulas WHERE id = :id_aula");

		$stmt->bindParam(":id_aula", $id_aula);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			return $row['id_curso'];
		} else {
			return 0;
		}
	}
}