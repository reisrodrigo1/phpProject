<?php
class Modulos extends model {

	public function getModulos($id_curso) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM modulos WHERE id_curso = :id_curso ORDER BY nome");

		$stmt->bindParam(":id_curso", $id_curso);

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetchAll();

			$aulas = new Aulas();

			foreach($array as $mChave => $mDados) {
				$array[$mChave]['aulas'] = $aulas->getAulasDoModulo($mDados['id']);
			}
		}
		return $array;
	}

	public function getModulo($id) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM modulos WHERE id = :id");

		$stmt->bindParam(":id", $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetch();
		}

		return $array;
	}

	public function addModulo($nome, $id_curso) {
		$stmt = $this->db->prepare("INSERT INTO modulos SET nome = :nome', id_curso = :id_curso");

		$stmt->bindParam(':id_curso', $id_curso);
		$stmt->bindParam(":nome", $nome);
		$stmt->execute();
	}

	public function deleteModulos($id) {
		$stmt = $this->db->prepare("SELECT id_curso FROM modulos WHERE id = :id");

		$stmt->bindParam(":id", $id);
		$stmt->execute();
		
		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			
			$stmt = $this->db->prepare("DELETE FROM modulos WHERE id = ?id");
			
			$stmt->bindParam(":id", $id);
			$stmt->execute();

			return $row['id_curso'];
		}
	}

	public function updateModulo($nome, $id) {
		$stmt = $this->db->prepare("SELECT id_curso FROM modulos WHERE id = :id");

		$stmt->bindParam(":id", $id);
		$stmt->execute();
		
		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			$stmt = $this->db->prepare("UPDATE modulos SET nome = :nome' WHERE id = :id");
			
			$stmt->bindParam(":id", $id);
			$stmt->bindParam(":nome", $nome);
			$stmt->execute();
			
			return $row['id_curso'];
		}
	}
}