<body>
  <nav class="navbar">
    <div class="container-fluid">
      <a href="<?php echo BASE; ?>" style="padding-left: 15%;">
        <div class="navbar-brand">
          <img src="<?php echo BASE; ?>/assets/images/kid.png" alt="foto">
          <h3 class="navbar-text nome"><?php echo $nome_aluno ?></h3>
        </div>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon hamburguer">
          &nbsp;
        </span>
      </button>
    </div>
  </nav>

  <div class="collapse" id="toggler-menu">
    <div class="navigation-nav">
      <ul class="navigation-list">
        <li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
        <?php foreach ($cursos as $curso) : ?>
          <li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
        <?php endforeach; ?>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
      </ul>
    </div>
  </div>


  <div class="ellipse"></div>

    <div class="kit">
      <img src="<?php echo BASE; ?>/assets/images/arduino.png" alt="Arduino" class="img-fluid kit-img">
      <img src="<?php echo BASE; ?>/assets/images/cursos/robo-branco.png" alt="Arduino" class="img-fluid kit-img">
      <h3 class="kit-titulo">Kit Arduino + Robótica Sustentável</h3>
      <div class="kit-meio">
        <ul class="meio-lista">
          <li class="meio-item kit-item">Arduino Uno</li>
          <li class="meio-item kit-item">Sensores</li>
          <li class="meio-item kit-item">Componentes eletrônicos</li>
          <li class="meio-item kit-item">Jumpers</li>
        </ul>
      </div>
      <div class="kit-meio">
        <ul class="meio-lista">
          <li class="meio-item kit-item">Protoboard</li>
          <li class="meio-item kit-item">Peças de montagem</li>
          <li class="meio-item kit-item">Motores</li>
          <li class="meio-item kit-item">Ferramentas</li>
        </ul>
      </div>
      <button type="button" class="baixo-botao kit-botao">Comprar por R$320,00</button>
    </div>
</body>