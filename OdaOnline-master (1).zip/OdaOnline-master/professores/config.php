<?php
require 'environment.php';

global $config;
$config = array();
if(ENVIRONMENT == 'production') {
	// Ambiente de producao
	$config['dbname'] = 'odaonl79_ead';
	$config['host'] = 'localhost';
	$config['dbuser'] = 'odaonl79_prod';
	$config['dbpass'] = 'Oficina@123';

	define("BASE", "https://odaonline.com.br/professores");
} else if(ENVIRONMENT == 'test'){
	// Ambiente de testes
	$config['dbname'] = 'odaonl79_teste';
	$config['host'] = 'localhost';
	$config['dbuser'] = 'odaonl79_teste';
	$config['dbpass'] = 'Oficina@123';

	define("BASE", "https://teste.odaonline.com.br/professores");
} else {
	// Ambiente de desenvolvimento
	$config['dbname'] = 'ead';
	$config['host'] = 'localhost';
	$config['dbuser'] = 'root';
	$config['dbpass'] = '';
	
	define("BASE", "http://localhost/ead/professores");
}


?>
