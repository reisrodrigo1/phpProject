	<nav class="navbar">
		<div class="container-fluid">
			<div class="navbar-brand">
				<h3 class="titulo"><?php echo $curso->getNome(); ?></h3>
				<h4 class="subtitulo">Home</h4>

			</div>
			<img src="<?php echo BASE; ?>/assets/images/cursos/<?php echo $curso->getImagem(); ?>" class="img" alt="foto">

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon hamburguer">
					&nbsp;
				</span>
			</button>
		</div>
	</nav>



	<div class="collapse" id="toggler-menu">
		<div class="navigation-nav">
			<ul class="navigation-list">
				<li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
				<?php foreach ($cursos as $curso) : ?>
					<li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
				<?php endforeach; ?>
				<li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
				<li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
				<li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
			</ul>
		</div>
	</div>


	<div class="ellipse"></div>

	<div class="container-fluid" style="width: 75%;">
		<div class="curso-materias">
			<h4 class="materia-titulo">O que você aprenderá:</h4>
			<div class="materia-info">
				<?php foreach ($descricao as $texto) : ?>
					<h4><span>&#x02713;</span><?php echo ($texto); ?></h4>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="container-fluid" style="width: 75%;">
		<div class="lista-videos">
			<div class="accordion">
				<?php foreach ($modulos as $modulo) : ?>
					<div class="accordion-item">
						<h2 class="accordion-header">
							<button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#id-<?php echo $modulo['id'] ?>">
								<div class="categoria">
									<?php echo $modulo['nome']; ?>
								</div>
							</button>
						</h2>
						<div id="id-<?php echo $modulo['id'] ?>" class="accordion-collapse collapse">
							<div class="accordion-body">
								<?php foreach ($modulo['aulas'] as $aula) : ?>
									<div class="accordion-conponent">
										<a href="<?php echo BASE; ?>/cursos/aula/<?php echo $aula['id']; ?>">
											<?php echo $aula['nome']; ?>
										</a>
									</div>
								<?php endforeach ?>

							</div>
						</div>
					</div>
				<?php endforeach; ?>


			</div>
		</div>




		<div class="curso_right">
		</div>
	</div>