<?php
class Usuarios extends model {

	private $info;

	public function isLogged() {
		if(isset($_SESSION['lgadmin']) && !empty($_SESSION['lgadmin'])) {
			return true;
		} else {
			return false;
		}
	}

	public function fazerLogin($email, $senha) {
		$stmt = $this->db->prepare("SELECT * FROM usuarios WHERE email = :email AND senha = :senha");

		$stmt->bindParam(":email", $email);
		$stmt->bindParam(":senha", $senha);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();

			$_SESSION['lgadmin'] = $row['id'];

			return true;
		}

		return false;

	}

}
?>