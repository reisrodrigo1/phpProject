<!doctype html>
<html lang="pt-br">

<head>
  <title>Professor - Oficina do Amanhã</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="<?php echo BASE; ?>/../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <link rel="stylesheet" href="<?php echo BASE; ?>/../assets/css/professores.css">
</head>

<body>
  <div class="wrapper ">
    <div class="sidebar" data-color="orange" data-background-color="white" data-image="">

      <div class="logo">
        <a href="<?php echo BASE; ?>" class="simple-text logo-normal">
          <img class="rounded mx-auto d-block" alt="100x100" src="<?php echo BASE; ?>/../assets/images/cursos/logo-cinza.png" width="130">
          <i class="material-icons">public</i>
          ODA Online
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">

          <li class="nav-item <?php if (PAGE == 'home') {
                                echo 'active';
                              } ?>">
            <a class="nav-link" href="<?php echo BASE; ?>">
              <i class="material-icons">dashboard</i>
              <p>Principal</p>
            </a>
          </li>

          <li class="nav-item <?php if (PAGE == 'oficinas') {
                                echo 'active';
                              } ?>">
            <a class="nav-link" href="<?php echo BASE; ?>/oficinas">
              <i class="material-icons">school</i>
              <p>Oficinas</p>
            </a>
          </li>

          <li class="nav-item <?php if (substr(PAGE, 0, 6) == 'alunos') {
                                echo 'active';
                              } ?>">
            <a class="nav-link" href="<?php echo BASE; ?>/alunos">
              <i class="material-icons">face</i>
              <p>Alunos</p>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo BASE; ?>/login/logout">
              <i class="material-icons">logout</i>
              <p>Sair</p>
            </a>
          </li>

        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <a class="navbar-brand" href="javascript:;">Bem-vindo(a), professor Fulano de Tal</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <!-- <li class="nav-item">
                <a class="nav-link" href="javascript:;">
                  <i class="material-icons">notifications</i> Notifications
                </a>
              </li> -->
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->

      <?php $this->loadViewInTemplate($viewName, $viewData); ?>


      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="http://www.oficinadoamanha.com.br/" target="_blank">
                  Oficina do Amanhã
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
        </div>
      </footer>
    </div>
  </div>

  <!--   Core JS Files   -->
  <script src="<?php echo BASE; ?>/../assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="<?php echo BASE; ?>/../assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="<?php echo BASE; ?>/../assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  <script src="<?php echo BASE; ?>/../assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>
  <!-- Chartist JS -->
  <script src="<?php echo BASE; ?>/../assets/js/plugins/chartist.min.js"></script>
  <!--  Notifications Plugin    -->
  <script src="<?php echo BASE; ?>/../assets/js/plugins/bootstrap-notify.js"></script>
  <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="<?php echo BASE; ?>/../assets/js/material-dashboard.js" type="text/javascript"></script>
  <!-- Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
  <script src="<?php echo BASE; ?>/../assets/js/plugins/jasny-bootstrap.min.js"></script>
</body>

</html>