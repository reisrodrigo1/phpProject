<body>
  <nav class="navbar">
    <div class="container-fluid">
      <a href="<?php echo BASE; ?>" style="padding-left: 15%;">
        <div class="navbar-brand">
          <img src="<?php echo BASE; ?>/assets/images/kid.png" alt="foto">
          <h3 class="navbar-text nome"><?php echo $nome_aluno ?></h3>
        </div>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon hamburguer">
          &nbsp;
        </span>
      </button>
    </div>
  </nav>

  <div class="collapse" id="toggler-menu">
    <div class="navigation-nav">
      <ul class="navigation-list">
        <li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
        <?php foreach ($cursos as $curso) : ?>
          <li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
        <?php endforeach; ?>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
      </ul>
    </div>
  </div>


  <div class="ellipse"></div>
<div style="margin-left: 35%">
  <div style="position: relative; width: 100%; height: 0; padding-top: 177.7778%;
 padding-bottom: 48px; box-shadow: 0 2px 8px 0 rgba(63,69,81,0.16); margin-top: 1.6em; margin-bottom: 0.9em; overflow: hidden;
 border-radius: 8px; will-change: transform;">
  <iframe style="position: absolute; width: 50%; height: 50%; top: 0; left: 0; border: none; padding: 0;margin: 0;"
    src="https://www.canva.com/design/DAEZCngXUE4/k4qPGU6hgOPwXxyuwIgCPw/view?website#2">
  </iframe>
</div>
        </div>
</body>