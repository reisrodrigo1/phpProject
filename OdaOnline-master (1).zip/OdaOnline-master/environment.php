<?php

if($_SERVER['HTTP_HOST'] == 'localhost'){
    define("ENVIRONMENT", "development");
}else if (strpos($_SERVER['HTTP_HOST'], 'teste.odaonline.com.br') !== false){
    define("ENVIRONMENT", "test");
} else if (strpos($_SERVER['HTTP_HOST'], 'odaonline.com.br') !== false){
    define("ENVIRONMENT", "production");
} else {
    die("Oops! Environment error!");
}

?>