<!DOCTYPE html>
<html lang="pt-br">

<head>
  <meta charset="utf-8" />

  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">


  <!-- Css -->

  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/assinaturas.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/kit.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/questionario.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/video.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/curso.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/accordion.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/home.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/global.css">





  <!-- Fontes -->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans&display=swap" rel="stylesheet">

  <!-- Icons -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">


  <title>
    Oficina do Amanhã
  </title>

</head>

<body>

  <?php $this->loadViewInTemplate($viewName, $viewData); ?>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>

</html>