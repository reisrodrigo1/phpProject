START TRANSACTION;


INSERT INTO `alunos` (`id`, `nome`, `email`, `senha`) VALUES
(default, 'Bonieky', 'suporte@b7web.com.br', '7363a0d0604902af7b70b271a0b96480'),
(default, 'Aluno de teste', 'aluno@teste.com', 'd9b1d7db4cd6e70935368a1efb10e377'),
(default, 'Rodrigo teste', 'reis.mrodrigo@outlook.com', '202cb962ac59075b964b07152d234b70'),
(default, 'Rodrigo Reis', 'reis.mrodrigo@gmail.com', '7363a0d0604902af7b70b271a0b96480'),
(default, 'Rodrigo Reis', 'reis.mrodrigo@gmail.com.br', '202cb962ac59075b964b07152d234b70');

INSERT INTO `cursos` (`id`, `nome`, `imagem`, `descricao`) VALUES
(default, 'ROBÓTICA SUSTENTÁVEL', 'robo-branco.png', 'Curso para desenvolvimento de sites e sistemas.'),
(default, 'PROGRAMAÇÃO', 'pc.png', NULL),
(default, 'ODAPAD', 'logo-cinza.png', NULL),
(default, 'ODA ONLINE PLUS', 'logo-cinza.png', 'Esse curso faz CSS parecer facil.');

INSERT INTO `modulos` (`id`, `id_curso`, `nome`) VALUES
(default, 1, 'Básico'),
(default, 1, 'Intermediário'),
(default, 1, 'Avançado'),
(default, 1, 'Super Avançado');

INSERT INTO `aulas` (`id`, `id_modulo`, `id_curso`, `ordem`, `tipo`) VALUES
(default, 1, 1, 1, 'video'),
(default, 1, 1, 2, 'video'),
(default, 2, 1, 1, 'video'),
(default, 2, 1, 2, 'poll'),
(default, 3, 1, 1, 'video'),
(default, 3, 1, 3, 'video'),
(default, 1, 1, 3, 'poll'),
(default, 1, 1, 4, 'video'),
(default, 1, 1, 5, 'video');


INSERT INTO `aluno_curso` (`id`, `id_curso`, `id_aluno`) VALUES
(default, 1, 4),
(default, 1, 1),
(default, 2, 1),
(default, 3, 1),
(default, 4, 1),
(default, 1, 2),
(default, 2, 2),
(default, 3, 2);

INSERT INTO `duvidas` (`id`, `data_duvida`, `respondida`, `duvida`, `id_aluno`, `resposta`) VALUES
(default, '2016-08-12 05:45:23', 0, 'Duvida de teste...', 1, NULL),
(default, '2021-01-17 15:59:28', NULL, 'fdsewrtwerf', 4, NULL),
(default, '2021-01-17 15:59:32', NULL, 'dsafgdfsd', 4, NULL);

INSERT INTO `historico` (`id`, `data_viewed`, `id_aluno`, `id_aula`) VALUES
(default, '2016-08-30 06:07:44', 1, 1),
(default, '2016-08-30 06:10:00', 1, 9),
(default, '2016-08-30 06:10:18', 1, 3),
(default, '2021-01-16 20:10:58', 1, 2);

INSERT INTO `oficinas` (`id`, `nome`, `oficina`, `aula`, `projeto`, `descricao`, `data`) VALUES
(default, 'Rodrigo Reis', 'Robótica', 'LEds', 'CDL', NULL, '17/01/2020'),
(default, 'Rodrigo Reis', NULL, 'LEDS', 'CDL', NULL, '2021-01-18'),
(default, 'Rodrigo Reis', NULL, 'Motores', 'CDL', NULL, '2021-01-19'),
(default, 'Rodrigo Reis', NULL, 'Motores 2', 'CDL', 'Problema com o aluno Rodrigo', '2021-01-18'),
(default, 'Rodrigo Reis', 'Programação', 'Semáforo', 'CDL', '', '2021-01-19');

INSERT INTO `questionarios` (`id`, `id_aula`, `pergunta`, `opcao1`, `opcao2`, `opcao3`, `opcao4`, `resposta`) VALUES
(default, 4, 'Qual a pergunta?', 'Op122', 'Op23333', 'Op35555', 'Op41111', 4),
(default, 7, 'Pergunta de teste', 'Opcoao1', 'copaosr2', 'aposri3', 'apsori4', 3);

INSERT INTO `usuarios` (`id`, `email`, `senha`) VALUES
(default, 'suporte@b7web.com.br', '202cb962ac59075b964b07152d234b70');

INSERT INTO `videos` (`id`, `id_aula`, `nome`, `descricao`, `url`) VALUES
(default, 1, 'Aula 1', '', 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 2, 'Aula 2', '', 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 3, 'Aula 3', NULL, 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 5, 'Aula 4', NULL, 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 6, 'Aula 5', NULL, 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 8, 'Aula Teste 2', '', 'https://www.youtube.com/embed/Ul1XuiJE0Dw'),
(default, 9, 'Leds', NULL, 'https://www.youtube.com/embed/Ul1XuiJE0Dw');

COMMIT;