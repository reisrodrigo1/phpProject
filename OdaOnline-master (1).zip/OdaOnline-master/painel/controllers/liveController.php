<?php
class liveController extends controller {

	public function __construct() {
		parent::__construct();
	}

    public function index() {
        $usuarios = new Usuarios();
        if($_SERVER["REQUEST_METHOD"] == "POST" && $usuarios->isLogged()){
            $lives = new Lives();

            if(isset($_POST["live-link"]) && !empty($_POST["live-link"]) && !$lives->isOn()){
                $link = $_POST["live-link"];
                
                if($lives->iniciar($link, $_SESSION["lgadmin"])){
                    $_SESSION["err_open_live"] = false;
                    header("Location: ".BASE);
                    exit;
                }
            }
            $_SESSION["err_open_live"] = true;
        }
        header("Location: ".BASE);
    }
    
    public function encerrar(){
        $usuarios = new Usuarios();
        if($usuarios->isLogged()){
            $lives = new Lives();
            if($lives->isOn() && $lives->encerrar()){
                $_SESSION["err_close_live"] = false;
                header("Location: ".BASE);
                exit;
            }
            $_SESSION["err_close_live"] = true;
        }
        header("Location: ".BASE);
    }
}

?>