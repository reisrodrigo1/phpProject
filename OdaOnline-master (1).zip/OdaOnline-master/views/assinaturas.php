<body>
  <nav class="navbar">
    <div class="container-fluid">
      <a href="<?php echo BASE; ?>" style="padding-left: 15%;">
        <div class="navbar-brand">
          <img src="<?php echo BASE; ?>/assets/images/kid.png" alt="foto">
          <h3 class="navbar-text nome"><?php echo $nome_aluno ?></h3>
        </div>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon hamburguer">
          &nbsp;
        </span>
      </button>
    </div>
  </nav>

  <div class="collapse" id="toggler-menu">
    <div class="navigation-nav">
      <ul class="navigation-list">
        <li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
        <?php foreach ($cursos as $curso) : ?>
          <li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
        <?php endforeach; ?>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
      </ul>
    </div>
  </div>


  <div class="ellipse"></div>

  <div class="assinatura">
          <div class="compra">
            <div class="promo">
              <p>MELHOR PREÇO</p>
            </div>
            <div class="top">
              <img src="<?php echo BASE; ?>/assets/images/cursos/robo-branco.png" alt="Robótica" class="img-fluid top-img">
              <h3 class="top-titulo">Robótica</h3>
            </div>

            <div class="meio">
              <ul class="meio-lista meio-lado">
                <li class="meio-item">Arduino</li>
                <li class="meio-item">Programação C</li>
                <li class="meio-item">Tinkercard</li>
                <li class="meio-item">Construção Sustentável</li>
                <li class="meio-item">E-book</li>
              </ul>
              <div class="meio-preco meio-lado">
             
                <p class="texto">de R$32,99</p>
                <p class="texto">por</p>
                <p class="preco">R$27,99</p>
                <p class="texto" onclick="mostrar()"><a href="#" style="text-weight: bold; color: #BE1E92;" >Assista ao vídeo</a></p>
               
              </div>
            </div>

            <div class="baixo">
              <form action="https://pagseguro.uol.com.br/pre-approvals/request.html" method="post" target="_blank">
                <input type="hidden" name="code" value="55D41434D6D6055FF4C1AFBD5BB81464" />
                <input type="hidden" name="iot" value="button" />
                
                <button type="submit" class="baixo-botao">Assinar</button>
              </form>
            </div>
          </div>


          <div class="compra">
            <div class="promo">
              <p>MELHOR PREÇO</p>
            </div>
            <div class="top">
              <img src="<?php echo BASE; ?>/assets/images/cursos/pc.png" alt="Programação" class="img-fluid top-img">
              <h3 class="top-titulo">Programação</h3>
            </div>

            <div class="meio">
              <ul class="meio-lista meio-lado">
                <li class="meio-item">Desenvolvimento Web</li>
                <li class="meio-item">GitHub</li>
                <li class="meio-item">Desenvolvimento Mobile</li>
                <li class="meio-item">Ferramentas de Mercado</li>
                <li class="meio-item">E-book</li>
              </ul>
              <div class="meio-preco meio-lado">
                <p class="texto">de R$32,99</p>
                <p class="texto">por</p>
                <p class="preco">R$27,99</p>
              </div>
            </div>

            <div class="baixo">
              <form action="https://pagseguro.uol.com.br/pre-approvals/request.html" method="post" target="_blank">
                <input type="hidden" name="code" value="C278C1C4DADA88E7748F8F876BE311EA" />
                <input type="hidden" name="iot" value="button" />
                <button type="submit" class="baixo-botao">Assinar</button>
              </form>
              
            </div>
          </div>


          <div class="compra compra-jogo">
            <div class="top">
              <img src="<?php echo BASE; ?>/assets/images/cursos/controle.png" alt="Games" class="img-fluid top-img">
              <h3 class="top-titulo">Games</h3>
            </div>

            <div class="meio">
              <ul class="meio-lista meio-lado">
                <li class="meio-item">Desenvolvimento</li>
                <li class="meio-item">Jogos 2D</li>
                <li class="meio-item">Jogos 3D</li>
                <li class="meio-item">Unreal Engine</li>
                <li class="meio-item">E-book</li>
              </ul>
              <div class="meio-preco meio-lado">
                <p class="jogo">EM</p>
                <p class="jogo">BREVE</p>
              </div>
            </div>

            <div class="baixo">
              <button type="button" class="baixo-botao lock-botao">
                <span class="material-icons">lock</span>
              </button>
            </div>
          </div>

  </div>


  <div id="videorobotica" class="" style="width:100%; height:75%;" >
  
	<div >
		<iframe style="
      width:75%;
      height:75%;
      display: block;
      margin-left: auto;
      margin-right: auto; 
      margin-top: 5%;
      -webkit-box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);
      -moz-box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);
      box-shadow: -5px 6px 21px 9px rgba(0,0,0,0.75);"
      class="video" id="video" src="https://www.youtube.com/embed/1R8c2_-dz_E" ?>" allowfullscreen></iframe>

	</div>
  <button onclick="ocultar()" class="baixo-botao" style="margin-top: -20px;">FECHAR</button>

</div>

</body>

<script language=javascript type="text/javascript">
function ocultar() {
  var element = document.getElementById("videorobotica");
  element.classList.remove("show");
}

function mostrar() {
  var element = document.getElementById("videorobotica");
  element.classList.add("show");
}
</script>