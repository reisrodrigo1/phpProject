<?php
class Lives extends model {
    
    public function iniciar($url, $id_usuario) {
        $stmt = $this->db->prepare("INSERT INTO lives SET url = :url, inicio = :inicio, id_usuario = :id_usuario");
        
        $inicio = date('Y-m-d H:i:s');
        $stmt->bindParam(":url", $url);
        $stmt->bindParam(":inicio", $inicio);
        $stmt->bindParam(":id_usuario", $id_usuario);
        $stmt->execute();

        // TODO: verificação de sucesso de inserção
        return true;
    }
    
    public function encerrar() {
        $stmt  = $this->db->prepare("UPDATE lives SET fim = :fim WHERE fim IS null");
        
        $fim = date('Y-m-d H:i:s');
        $stmt->bindParam(":fim", $fim);
        $stmt->execute();
        
        // TODO: verificação de sucesso
        return true;
    }

    public function isOn(){
        // Checa se alguma live está aberta nesse momento

        // aberta = live com fim NULL

        $sql = $this->db->query("SELECT * FROM lives WHERE fim IS null;");
        if($sql->fetch()){
            return true;
        }
        return false;
    }
}

?>