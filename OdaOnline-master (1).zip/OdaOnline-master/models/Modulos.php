<?php
class Modulos extends model {

	public function getModulos($id_curso) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM modulos WHERE id_curso = :id_curso ORDER BY nome");

		$stmt->bindParam(':id_curso', $id_curso);
		$stmt->execute();

		if($stmt->rowCount() > 0) {

			$array = $stmt->fetchAll();

			$aulas = new Aulas();

			
			
			foreach($array as $mChave => $mDados) {
				$array[$mChave]['aulas'] = $aulas->getAulasDoModulo($mDados['id']);
			}

		}

		return $array;
	}

}