<nav class="navbar">
  <div class="container-fluid">
    <div class="navbar-brand" href="#">
      <img src="<?php echo BASE; ?>/assets/images/kid.png" alt="foto">
      <h3 class="navbar-text nome"><?php echo $nome_aluno ?></h3>
    </div>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon hamburguer">
        &nbsp;
      </span>
    </button>
  </div>
</nav>

<div class="collapse" id="toggler-menu">
  <div class="navigation-nav">
    <ul class="navigation-list">
      <li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
      <?php foreach ($cursos as $curso) : ?>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
      <?php endforeach; ?>
      <li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
      <li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
      <li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
    </ul>
  </div>
</div>


<div class="ellipse"></div>
<div class="container-fluid" style="width: 75%;">
  <div class="shelf">
    <div class="row">

      <?php foreach ($cursos as $curso) : ?>
        <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
          <a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="box open-box">
            <img src="<?php echo BASE; ?>/assets/images/cursos/<?php echo $curso['imagem']; ?>" alt="<?php echo $curso['nome']; ?>" class="box-img">
            <h3 class="box-title"><?php echo $curso['nome']; ?></h3>
          </a>
        </div>
      <?php endforeach; ?>

      <?php foreach ($cursos2 as $curso2) : ?>
        <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
          <a href="<?php echo BASE; ?>/assinaturas" class="box close-box">
            <img src="<?php echo BASE; ?>/assets/images/cursos/<?php echo $curso2['imagem']; ?>" alt="<?php echo $curso2['nome']; ?>" class="box-img">
            <h3 class="box-title"><?php echo $curso2['nome']; ?></h3>
            <img src="<?php echo BASE; ?>/assets/images/cadeado-branco.png" alt="cadeado" class="cadeado">
          </a>
        </div>
      <?php endforeach; ?>

      <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
        <?php if(isset($url_live)): ?>
          <a href="<?php echo $url_live; ?>" target="_blank" class="box open-box live-on">
            <img src="<?php echo BASE; ?>/assets/images/ao-vivo.gif" alt="Live" class="img-fluid box-img">
          </a>
        <?php else: ?>
          <div class="box close-box live-off">
            <img src="<?php echo BASE; ?>/assets/images/videocam_off.svg" alt="Live" class="img-fluid box-img">
            <h3 class="box-title">LIVE</h3>
          </div>
        <?php endif ?>
        
      </div>

      <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
        <a href="https://discord.gg/D9S2GnKm" target="_blank" class="box open-box">
          <img src="<?php echo BASE; ?>/assets/images/cursos/discord.png" alt="Discord" class="img-fluid box-img">
          <h3 class="box-title">DISCORD</h3>
        </a>
      </div>
      <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
        <a href="<?php echo BASE; ?>/assinaturas" class="box open-box">
          <img src="<?php echo BASE; ?>/assets/images/cursos/logo-vertical.png" alt="Assinatura" class="img-fluid box-img">
          <h3 class="box-title">ASSINATURA</h3>
        </a>
      </div>

      <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
        <a href="<?php echo BASE; ?>/kits" class="box open-box">
          <img src="<?php echo BASE; ?>/assets/images/cursos/logo-vertical.png" alt="Kits" class="img-fluid box-img">
          <h3 class="box-title">KITS</h3>
        </a>
      </div>

      <div class="col-lg-4 col-sm-6 d-flex justify-content-center">
        <a href="<?php echo BASE; ?>/apostilas" class="box open-box">
          <img src="<?php echo BASE; ?>/assets/images/cursos/logo-vertical.png" alt="Apostilas" class="img-fluid box-img">
          <h3 class="box-title">APOSTILAS</h3>
        </a>
      </div>

    </div>
  </div>
</div>