<div class="content">
        <div class="container-fluid">
            
          <!-- Cards principais -->
          <div class="row">

            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Lista de Oficinas</h4>
                </div>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead class="text-primary">
                        <tr>
                          <th>Oficina</th>
                          <th>Aula</th>
                          <th>Projeto</th>
                          <th>Descrição</th>
                          <th>Data</th>
                        </tr>
                      </thead>
                      <tbody>

                        <?php foreach($oficinas as $oficina): ?>
                        <tr>
                          <td><?php echo $oficina['oficina'];?></td>
                          <td><?php echo $oficina['aula'];?></td>
                          <td><?php echo $oficina['projeto'];?></td>
                          <td><?php echo $oficina['descricao'];?></td>
                          <td><?php echo $oficina['data'];?></td>
                        </tr>
                        <?php endforeach; ?>

                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>

          </div>



        </div>
      </div>