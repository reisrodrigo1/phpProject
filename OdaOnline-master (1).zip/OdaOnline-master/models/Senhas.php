<?php
class Senhas extends model {

	private $info;

	public function addRecuperaSenha($email, $rash){

		$stmt = $this->db->prepare("INSERT INTO recuperar SET email = :email, rash = :rash");
		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':rash', $rash);

		$stmt->execute();

		return true;
	}

	public function verifica_rash($rash){
		
		$stmt  = $this->db->prepare("SELECT * FROM recuperar WHERE rash = :rash AND status = 0");

		$stmt->bindParam(':rash', $rash);
		$stmt->execute();

		return $stmt->rowCount();
	}

	public function atualiza_senha($rash, $senha){
		$stmt = $this->db->prepare("SELECT email FROM recuperar WHERE rash = :rash");
		$stmt->bindParam(':rash', $rash);
		$stmt->execute();

		$email = $stmt->fetch();
		$email_user = $email['email'];
		
		$stmt = $this->db->prepare("UPDATE alunos SET senha = :senha WHERE email = :email");
		$stmt->bindParam(':email', $email_user);
		$stmt->bindParam(':senha', $senha);
		$stmt->execute();
	}


	public function deleta_rash($rash){
		$stmt = $this->db->prepare("SELECT email FROM recuperar WHERE rash = :rash");
		$stmt->bindParam(':rash', $rash);
		$stmt->execute();

		$email = $stmt->fetch();
		$email_user = $email['email'];
		
		$stmt = $this->db->prepare("DELETE FROM recuperar WHERE email = :email");
		$stmt->bindParam(':email', $email_user);
		$stmt->execute();
	}



     public function redirecionar($dir, $time){
          echo "<meta http-equiv='refresh' content='{$time}; url={$dir}'>";
     }

	
}
?>