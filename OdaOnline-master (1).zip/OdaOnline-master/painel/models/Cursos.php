<?php
class Cursos extends model {

	public function getCursos() {
		$array = array();

		$sql = "SELECT 
			*, (select count(*) from aluno_curso where aluno_curso.id_curso = cursos.id) as qtalunos 
			FROM cursos";
		$sql = $this->db->query($sql);

		if($sql->rowCount() > 0) {
			$array = $sql->fetchAll();
		}

		return $array;
	}

	public function getCurso($id) {
		$array = array();

		$stmt = $this->db->prepare("SELECT * FROM cursos WHERE id = :id");
		
		$stmt->bindParam(":id", $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$array = $stmt->fetch();
		}

		return $array;
	}

	public function getCursosInscritos($id_aluno) {
		$array = array();

		$stmt = $this->db->prepare("SELECT id_curso FROM aluno_curso WHERE id_aluno = :id_aluno");

		$stmt->bindParam(":id_aluno", $id_aluno);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$rows = $stmt->fetchAll();

			foreach($rows as $row) {
				$array[] = $row['id_curso'];
			}
		}

		return $array;
	}

	public function deleteCurso($id) {
		$path = getcwd()."/../assets/images/cursos/";
		$image = $this->getImage($id);
		if(!file_exists($path.$image) || unlink($path.$image)){
			// Imagem deletada com sucesso
			$stmt = $this->db->prepare("DELETE FROM cursos WHERE id = ?");
			if($stmt->execute([$id])){
				return true;
			}
		}
		return false;
	}

	public function updateCurso($id, $nome, $descricao, $imagem){
		$stmt = $this->db->prepare("UPDATE cursos SET nome = :nome, descricao = :descricao WHERE id = :id");

		$stmt->bindParam(':nome', $nome);
		$stmt->bindParam(':descricao', $descricao);
		$stmt->bindParam(':id', $id);
		$stmt->execute();
		
		if(!empty($imagem['tmp_name'])) {

			$path = getcwd()."/../assets/images/cursos/";
			$image = $this->getImage($id);

			if(!file_exists($path.$image) || unlink($path.$image)){
				// Imagem deletada com sucesso, insere a nova imagem
				$md5name = md5(time().rand(0,9999)).'.png';
				$types = array('image/jpeg', 'image/jpg', 'image/png');
				
				if(in_array($imagem['type'], $types)) {
					move_uploaded_file($imagem['tmp_name'], "../assets/images/cursos/".$md5name);
					
					$stmt = $this->db->prepare("UPDATE cursos SET imagem = :md5name WHERE id = :id");
					$stmt->bindParam(':md5name', $md5name);
					$stmt->bindParam(':id', $id);
					$stmt->execute();
				}
			} else {
				return false;
			}
		}
		return true;
	}

	public function addCurso($nome, $descricao, $imagem) {
		$md5name = md5(time().rand(0,9999)).'.png';

		if(!empty($imagem['tmp_name'])) {

			$types = array('image/jpeg', 'image/jpg', 'image/png');

			if(in_array($imagem['type'], $types)) {
				move_uploaded_file($imagem['tmp_name'], "../assets/images/cursos/".$md5name);
			} else {
				return false;
			}
		} else {
			copy("../assets/images/cursos/logo-cinza.png", "../assets/images/cursos/".$md5name);
		}
		
		$stmt = $this->db->prepare("INSERT INTO cursos SET nome = :nome, descricao = :descricao, imagem = :md5name");

		$stmt->bindParam(':nome', $nome);
		$stmt->bindParam(':descricao', $descricao);
		$stmt->bindParam(':md5name', $md5name);
		$stmt->execute();

		return true;
	}

	public function getImage($id){
		$stmt = $this->db->prepare("SELECT imagem FROM cursos WHERE id = ?");
		$stmt->execute([$id]);
		return $stmt->fetch()["imagem"];
	}
}
?>