<?php
class Alunos extends model {

	private $info;

	public function isLogged() {
		if(isset($_SESSION['lgaluno']) && !empty($_SESSION['lgaluno'])) {
			return true;
		} else {
			return false;
		}
	}

	public function fazerLogin($email, $senha) {
		$stmt = $this->db->prepare("SELECT * FROM alunos WHERE email = :email AND senha = :senha");

		$stmt->bindParam(':email', $email);
		$stmt->bindParam(':senha', $senha);
		$stmt->execute();
		
		if($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			
			$_SESSION['lgaluno'] = $row['id'];

			return true;
		}

		return false;

	}
	
	public function cadastro($nome, $email, $senha, $nome_responsavel, $cupom) {
		$stmt = $this->db->prepare("SELECT * FROM alunos WHERE email = :email");

		$stmt->bindParam(':email', $email);
		$stmt->execute();

		if($stmt->rowCount() == 0) {

			$stmt = $this->db->prepare("INSERT INTO alunos SET nome = :nome, email = :email, senha = MD5(:senha), responsavel = :responsavel, cupom = :cupom");
			
			$stmt->bindParam(':nome', $nome);
			$stmt->bindParam(':email', $email);
			$stmt->bindParam(':senha', $senha);
			$stmt->bindParam(':responsavel', $nome_responsavel);
			$stmt->bindParam(':cupom', $cupom);
			$stmt->execute();

			return true;
		} else {
			return false;
		}

	}



	public function isInscrito($id_curso) {
		$stmt = $this->db->prepare("SELECT * FROM aluno_curso WHERE id_aluno = :id_aluno AND id_curso = :id_curso");

		$stmt->bindParam(':id_aluno', $this->info['id']);
		$stmt->bindParam(':id_curso', $id_curso);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			return true;
		} else {
			return false;
		}
	}

	public function setAluno($id) {
		$stmt = $this->db->prepare("SELECT * FROM alunos WHERE id = :id");
		
		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$this->info = $stmt->fetch();
		}
	}

	public function setUsuarios($id) {

		$stmt = $this->db->prepare("SELECT * FROM usuarios WHERE id = :id");

		$stmt->bindParam(':id', $id);
		$stmt->execute();

		if($stmt->rowCount() > 0) {
			$this->info = $stmt->fetch();
		}

	}

	public function getNome() {
		return $this->info['nome'];
	}

	public function getId() {
		return $this->info['id'];
	}

	public function getNumAulasAssistidas($id_curso) {
		$sql = "
		SELECT id
		FROM historico
		WHERE
			id_aluno = :id_aluno
			AND id_aula IN (select aulas.id from aulas where aulas.id_curso = :id_curso)
		";
		
		$stmt = $this->db->prepare($sql);

		$id_aluno = $this->getId();
		$stmt->bindParam(':id_aluno', $id_aluno);
		$stmt->bindParam(':id_curso', $id_curso);
		$stmt->execute();

		return $stmt->rowCount();
	}

	public function getNumAulasAssistidas2($id) {

		$stmt  = $this->db->prepare("SELECT id FROM historico WHERE id_aluno = :id_aluno");

		$stmt->bindParam(':id_aluno', $id);
		$stmt->execute();

		return $stmt->rowCount();
	}

	
	public function getNumAulas2() {
		$sql = "SELECT id FROM aulas";
		$sql = $this->db->query($sql);
		
		return $sql->rowCount();
	}
	
	public function getEmailsAlunos($email) {

		$stmt  = $this->db->prepare("SELECT * FROM alunos WHERE email = :email");
		$stmt->bindParam(':email', $email);
		$stmt->execute();

		return $stmt->rowCount();
	}

}
?>