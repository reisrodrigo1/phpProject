<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/login.css">
  <link rel="stylesheet" href="<?php echo BASE; ?>/assets/css/global.css">


  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

  <!-- Icon https://material.io/resources/icons/?style=baseline-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

  <title>ODA Online</title>

</head>

<body id="LoginForm">
  <div class="container-fluid">
    <form class="form-signin" id="Login" method="POST">
      <img class=" img-logo" src="<?php echo BASE; ?>/assets/images/cursos/logo-vertical.png" alt="Oficina Do Amanhã">
      
      <?php if (isset($err_email)) echo "<p class='err'>" . $err_email . "</p>" ?>
      <?php if (isset($suc_email)) echo "<p class='suc'>" . $suc_email . "</p>" ?>

      <div class="form-group">
        <input type="email" id="inputEmail" name="email" class="form-input" placeholder="Email de confirmação" required="true">
        <label for="inputEmail" class="form-label">Email de confirmação</label>
      </div>

      <button class="btn btn-lg btn-primary btn-block botao" type="submit">
        Recuperar
      </button>
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
</body>

</html>