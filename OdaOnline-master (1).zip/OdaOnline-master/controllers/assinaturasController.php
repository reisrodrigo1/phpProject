<?php
class assinaturasController extends controller {

	public function __construct() {
		parent::__construct();
		$alunos = new Alunos();

		if(!$alunos->isLogged()) {
			header("Location: ".BASE."/login");
		}
	}
	
	public function index() {
		$dados = array(
			'info' => array(),
			'cursos' => array()
		);

		$alunos = new Alunos();
		$alunos->setAluno($_SESSION['lgaluno']);
		$dados['info'] = $alunos;
		$dados['nome_aluno'] = $alunos->getNome();
		$dados['aulas_assistidas2'] = $alunos->getNumAulasAssistidas2($alunos->getId());
		$dados['aulas_aulas2'] = $alunos->getNumAulas2();

		$cursos = new Cursos();
		$dados['cursos'] = $cursos->getCursosDoAluno($alunos->getId());
		

		
		$this->loadTemplate('assinaturas', $dados);
	}

}