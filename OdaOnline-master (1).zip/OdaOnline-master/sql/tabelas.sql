SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "-03:00";

-- --------------------------------------------------------

--
-- Table structure for table `alunos`
--

CREATE TABLE IF NOT EXISTS `alunos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `email` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `senha` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  `created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cupom` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `responsavel` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `cursos`
--

CREATE TABLE IF NOT EXISTS `cursos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `imagem` varchar(37) COLLATE utf8_bin NOT NULL DEFAULT '',
  `descricao` text COLLATE utf8_bin,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `aluno_curso`
--

CREATE TABLE IF NOT EXISTS `aluno_curso` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_curso` int(11) UNSIGNED NOT NULL,
  `id_aluno` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_curso`) REFERENCES cursos(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`id_aluno`) REFERENCES alunos(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `modulos`
--

CREATE TABLE IF NOT EXISTS `modulos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_curso` int(11) UNSIGNED NOT NULL,
  `nome` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_curso`) REFERENCES cursos(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `aulas`
--

CREATE TABLE IF NOT EXISTS `aulas` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_modulo` int(11) UNSIGNED NOT NULL,
  `id_curso` int(11) UNSIGNED NOT NULL,
  `ordem` int(11) NOT NULL,
  `tipo` varchar(20) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_modulo`) REFERENCES modulos(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`id_curso`) REFERENCES cursos(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `duvidas`
--

CREATE TABLE IF NOT EXISTS `duvidas` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_duvida` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `respondida` tinyint(1) DEFAULT NULL,
  `duvida` text COLLATE utf8_bin,
  `id_aluno` int(11) UNSIGNED DEFAULT NULL,
  `resposta` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_aluno`) REFERENCES alunos(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `historico`
--

CREATE TABLE IF NOT EXISTS `historico` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `data_viewed` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `id_aluno` int(11) UNSIGNED NOT NULL,
  `id_aula` int(11) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_aluno`) REFERENCES alunos(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`id_aula`) REFERENCES aulas(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `senha` varchar(32) COLLATE utf8_bin NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `horarios`
--

CREATE TABLE IF NOT EXISTS `horarios` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) UNSIGNED DEFAULT NULL,
  `data` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `valor` varchar(15) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_usuario`) REFERENCES usuarios(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `lives`
--

CREATE TABLE IF NOT EXISTS `lives` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) UNSIGNED DEFAULT NULL,
  `url` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `inicio` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fim` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_usuario`) REFERENCES usuarios(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `oficinas`
--

CREATE TABLE IF NOT EXISTS `oficinas` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_usuario` int(100) UNSIGNED DEFAULT NULL,
  `nome` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `oficina` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `aula` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `projeto` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `turma` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `descricao` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `data` varchar(10000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_usuario`) REFERENCES usuarios(`id`) ON DELETE SET NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `questionarios`
--

CREATE TABLE IF NOT EXISTS `questionarios` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_aula` int(11) UNSIGNED NOT NULL,
  `pergunta` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `opcao1` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `opcao2` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `opcao3` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `opcao4` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `resposta` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_aula`) REFERENCES aulas(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `videos`
--

CREATE TABLE IF NOT EXISTS `videos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_aula` int(11) UNSIGNED NOT NULL,
  `nome` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `descricao` text COLLATE utf8_bin,
  `url` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`id_aula`) REFERENCES aulas(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;


-- --------------------------------------------------------

--
-- Table structure for table `recuperar`
--


CREATE TABLE IF NOT EXISTS `recuperar` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `email` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `rash` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `status` int(20) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

COMMIT;