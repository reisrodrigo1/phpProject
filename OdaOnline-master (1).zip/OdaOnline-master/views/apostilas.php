<body>
  <nav class="navbar">
    <div class="container-fluid">
      <a href="<?php echo BASE; ?>" style="padding-left: 15%;">
        <div class="navbar-brand">
          <img src="<?php echo BASE; ?>/assets/images/kid.png" alt="foto">
          <h3 class="navbar-text nome"><?php echo $nome_aluno ?></h3>
        </div>
      </a>

      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#toggler-menu" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon hamburguer">
          &nbsp;
        </span>
      </button>
    </div>
  </nav>

  <div class="collapse" id="toggler-menu">
    <div class="navigation-nav">
      <ul class="navigation-list">
        <li class="navigation-item"><a href="<?php echo BASE; ?>" class="navigation-link">Home</a></li>
        <?php foreach ($cursos as $curso) : ?>
          <li class="navigation-item"><a href="<?php echo BASE; ?>/cursos/entrar/<?php echo $curso['id_curso']; ?>" class="navigation-link"><?php echo $curso['nome']; ?></a></li>
        <?php endforeach; ?>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/assinaturas" class="navigation-link">Assinaturas</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/kits" class="navigation-link">Kits</a></li>
        <li class="navigation-item"><a href="<?php echo BASE; ?>/login/logout" class="navigation-link">Sair</a></li>
      </ul>
    </div>
  </div>


  <div class="ellipse"></div>

  <div class="assinatura" style="margin-top: 100px;">
  <div class="compra apostila">
          
          <div class="top">
            <img src="<?php echo BASE; ?>/assets/images/componentes.png" alt="Robótica" class="img-fluid top-img">
           
         
          </div>

          <div class="baixo">
            
          <a target="_blank" href="https://www.canva.com/design/DAEZ-b5Ah7I/pFYOFc9YX92Y4ZxwFF1uEg/view?website#2" > 
          <button type="button" class="baixo-botao">ACESSAR</button> 
        </a>
          
          </div>
        </div>

        <div class="compra apostila">
          
          <div class="top">
            <img src="<?php echo BASE; ?>/assets/images/projetos.png" alt="Robótica" class="img-fluid top-img">
           </div>

          <div class="baixo">
           <a target="_blank" href="https://www.canva.com/design/DAEa0t3vv_M/7TfKoa6TNDSDqVIqmxYwCw/view?website#2" > 
           <button type="button" class="baixo-botao">ACESSAR</button> 
        </a>
           </div>
        </div>

        <div class="compra apostila">
          
          <div class="top">
            <img src="<?php echo BASE; ?>/assets/images/programacao.png" alt="Robótica" class="img-fluid top-img">
           </div>

          <div class="baixo">
           <a target="_blank" href="https://www.canva.com/design/DAEZsWN4XxE/C0IZPGz45fkJwttYUrCwlg/view?website#2" > 
           <button type="button" class="baixo-botao">ACESSAR</button> 
        </a>
           </div>
        </div>
         

  </div>
</body>