<?php
class Aulas extends model {

	public function marcarAssistido($id_aula) {
		$id_aluno = $_SESSION['lgaluno'];
		
		$stmt = $this->db->prepare("INSERT INTO historico SET data_viewed = NOW(), id_aluno = :id_aluno, id_aula = :id_aula");
		
		$stmt->bindParam(':id_aluno', $id_aluno);
		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();
	}

	public function getAulasDoModulo($id_modulo) {
		$array = array();
		$aluno = $_SESSION['lgaluno'];

		$stmt = $this->db->prepare("SELECT * FROM aulas WHERE id_modulo = :id_modulo ORDER BY ordem");
		
		$stmt->bindParam(':id_modulo', $id_modulo);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			$array = $stmt->fetchAll();


			foreach ($array as $aulachave => $aula) {
				$array[$aulachave]['assistido'] = $this->isAssistido($aula['id'], $aluno);

				if ($aula['tipo'] == 'video') {
					$stmt = $this->db->prepare("SELECT nome FROM videos WHERE id_aula = :id_aula");

					$stmt->bindParam(':id_aula', $aula['id']);
					$stmt->execute();

					$row = $stmt->fetch();

					$array[$aulachave]['nome'] = $row['nome'];
				} elseif ($aula['tipo'] == 'poll') {
					$array[$aulachave]['nome'] = "Questionário";
				}
			}
		}

		return $array;
	}

	public function getCursoDeAula($id_aula) {
		$stmt = $this->db->prepare("SELECT id_curso FROM aulas WHERE id = :id_aula");

		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			$row = $stmt->fetch();
			return $row['id_curso'];
		} else {
			return 0;
		}
	}

	public function getAula2($id_aula) {
		$stmt = $this->db->prepare("SELECT * FROM aulas JOIN modulos ON aulas.id_modulo = modulos.id WHERE aulas.id = :id_aula");

		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			$array = $stmt->fetch();
		}

		return $array;
	}

	public function getAula($id_aula) {
		$array = array();

		$id_aluno = $_SESSION['lgaluno'];

		$sql = "
		SELECT 
			tipo,
			(select count(*) from historico where historico.id_aula = aulas.id and historico.id_aluno = :id_aluno) as assistido
		FROM 
			aulas 
		WHERE 
			id = :id_aula";
		
		$stmt = $this->db->prepare($sql);

		$stmt->bindParam(':id_aluno', $id_aluno);
		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			$row = $stmt->fetch();

			$sql = '';
			if ($row['tipo'] == 'video') {
				$sql = "SELECT * FROM videos WHERE id_aula = :id_aula";

			} elseif ($row['tipo'] == 'poll') {
				$sql = "SELECT * FROM questionarios WHERE id_aula = :id_aula";

			}
			
			$stmt = $this->db->prepare($sql);
			
			$stmt->bindParam(':id_aula', $id_aula);
			$stmt->execute();
			
			$array = $stmt->fetch();

			$array['tipo']= $row['tipo'];

			$array['assistido'] = $row['assistido'];

		}

		return $array;
	}

	public function setDuvida($duvida, $id_aluno) {
		$stmt = $this->db->prepare("INSERT INTO duvidas SET data_duvida = NOW(), duvida = :duvida, id_aluno = :id_aluno");

		$stmt->bindParam(':duvida', $duvida);
		$stmt->bindParam(':id_aluno', $id_aluno);
		$stmt->execute();
	}

	private function isAssistido($id_aula, $id_aluno) {
		$stmt = $this->db->prepare("SELECT id FROM historico WHERE id_aluno = :id_aluno AND id_aula = :id_aula");
		
		$stmt->bindParam(':id_aluno', $id_aluno);
		$stmt->bindParam(':id_aula', $id_aula);
		$stmt->execute();

		if ($stmt->rowCount() > 0) {
			return true;
		} else {
			return false;
		}

	}
}