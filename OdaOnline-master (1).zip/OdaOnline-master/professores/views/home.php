
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->

          <!-- Cards principais -->
          <div class="row">
            
            <div class="col-lg-4 col-md-6 col-sm-6">
              <a href="<?php echo BASE; ?>/home/iniciar">
                <div class="card card-stats">
                  <div class="card-header card-header-success card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons">play_arrow</i>
                    </div>
                    <p class="card-category">Controle de Expediente</p>
                    <h3 class="card-title">Iniciar</h3>
                  </div>
                  <div class="card-footer">
                    <div class="stats">
                      <i class="material-icons">event</i> Iniciado por último em 10/02/2021, 14:00 
                    </div>
                  </div>
                </div>
              </a>
            </div>
            
            <div class="col-lg-4 col-md-6 col-sm-6">
              <a href="<?php echo BASE; ?>/home/encerrar">
                <div class="card card-stats">
                  <div class="card-header card-header-danger card-header-icon">
                    <div class="card-icon">
                      <i class="material-icons">stop</i>
                    </div>
                    <p class="card-category">Controle de Expediente</p>
                    <h3 class="card-title">Encerrar</h3>
                  </div>
                  <div class="card-footer">
                    <div class="stats">
                      <i class="material-icons">event</i> Encerrado por último em 10/02/2021, 18:00
                    </div>
                  </div>
                </a>
              </div>
            </div>
            
          </div>

          <div class="row">

            <div class="card">
              
              <div class="card-header card-header-primary">
                <h3 class="card-title ">Adicionar Oficina</h3>
                <p class="card-category">Preencha os dados referentes à oficina dada</p>
              </div>

              <div class="card-body">
                <form method="POST" action="<?php echo BASE; ?>/home/adicionar">              
                    
                  <div class="form-group has-primary">
                    <label class="  text-primary" for="nome">Professor</label>
                    <input class="form-control" type="text" name="nome" id="nome">
                  </div>

                  <div class="form-row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="  text-primary" for="oficina">Oficina</label>
                        <input class="form-control" type="text" name="oficina" id="oficina">
                      </div>
                    </div>

                    <div class="col-md-6">
                      <div class="form-group">
                        <label class="  text-primary" for="aula">Aula</label>
                        <input class="form-control" type="text" name="aula" id="aula">
                      </div>
                    </div>
                  </div>

                  <div class="form-row">
                    <div class="col-md-8">
                      <div class="form-group ">
                        <label class="  text-primary" for="projeto">Projeto</label>
                        <input class="form-control" type="text" name="projeto" id="projeto">
                      </div>
                    </div>

                    <div class="col-md-4">
                      <div class="form-group">
                        <label class="  text-primary" for="data">Data</label>
                        <input class="form-control" type="date" name="data" id="data">
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="  text-primary" for="descricao">Descrição</label>
                    <textarea class="form-control" name="descricao" id="descricao" rows="5"></textarea>
                  </div>
                  
                  <button type="submit" class="btn btn-primary pull-right">
                    Adicionar
                  </button>
                
                </form>
              </div>
            </div>
          
          </div>

        </div>
      </div>
